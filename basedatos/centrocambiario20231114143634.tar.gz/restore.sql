--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cc;
--
-- Name: cc; Type: DATABASE; Schema: -; Owner: geras
--

CREATE DATABASE cc WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'es_ES.UTF-8';


ALTER DATABASE cc OWNER TO geras;

\connect cc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpython3u; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpython3u WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpython3u; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpython3u IS 'PL/Python3U untrusted procedural language';


--
-- Name: bancomexicodivisa(text, text); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.bancomexicodivisa(precio text, fecha text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    -- Intenta insertar el precio y la fecha en la tabla tipo_cambio
    INSERT INTO tipo_cambio (dato, fecha) VALUES (precio, fecha::date);
    
    -- Si la inserción fue exitosa, devuelve un mensaje JSON de éxito
		PERFORM  enviar_correo('sistemas@inmtec.net','Tarea Programada Tipo Divisa','Se registro correctamente el tipo de cambio de acuerdo a banco de mexico a feha '||fecha||' con tipo de cambio de '|| precio );
		PERFORM  enviar_correo('victor-luna@inmtec.net','Tarea Programada Tipo Divisa','Se registro correctamente el tipo de cambio de acuerdo a banco de mexico a feha '||fecha||' con tipo de cambio de '|| precio );
    result := json_build_object('action', 'success', 'message', 'Registro insertado correctamente');
    RETURN result;
EXCEPTION
    -- En caso de error, captura la excepción y devuelve un mensaje JSON de error
    WHEN OTHERS THEN
        result := json_build_object('action', 'error', 'message', SQLERRM);
				PERFORM  enviar_correo('victor-luna@inmtec.net','Tarea Programada Tipo Divisa Banxico ERROR', SQLERRM);
								PERFORM  enviar_correo('sistemas@inmtec.net','Tarea Programada Tipo Divisa Banxico ERROR', SQLERRM);

        RETURN result;
END;
$$;


ALTER FUNCTION public.bancomexicodivisa(precio text, fecha text) OWNER TO geras;

--
-- Name: FUNCTION bancomexicodivisa(precio text, fecha text); Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON FUNCTION public.bancomexicodivisa(precio text, fecha text) IS 'funcion para guardar el tipo de cambio de la divisa
';


--
-- Name: divisas_dia(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.divisas_dia(data jsonb) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  a RECORD;
  b RECORD;
  c RECORD;
  usuario_data JSONB;
  RESULT JSONB[] = '{}';
  usuario INT;
  sucursal INT;
BEGIN
  -- Obtener los datos del usuario activo
  SELECT
    CASE
      WHEN perfilid = 1 THEN 1
      WHEN encargado = true THEN 2
      ELSE 3
    END,
    sucursalid
  INTO
    usuario,
    sucursal
  FROM usuarios
  WHERE userid = (data->>'idusuario')::INT;

  IF usuario = 1 THEN
    FOR a IN (SELECT * FROM sucursales ORDER BY empresaid, sucursalid) LOOP
      FOR b IN (SELECT * FROM grupodivisa) LOOP
        SELECT compra, venta, fecha INTO c
        FROM (
          SELECT *,
            ROW_NUMBER() OVER (PARTITION BY grupoid, sucursalid ORDER BY fecha DESC) AS rn
          FROM divisas
          WHERE grupoid = b.idgrupo AND sucursalid = a.sucursalid AND fecha::DATE = CURRENT_DATE
        ) ranked
        WHERE rn = 1;

        RESULT := RESULT || JSONB_BUILD_OBJECT('sucursal', a.nombre_sucursal, 'idgrupo', b.idgrupo, 'grupo', b.grupo, 'compra', c.compra::text, 'venta', c.venta::text, 'fecharegistro', c.fecha,'sucursalid',a.sucursalid);
      END LOOP;
    END LOOP;
  ELSIF usuario = 2 THEN
    FOR a IN (SELECT * FROM sucursales WHERE sucursalid IN (SELECT sucursalid FROM encargadosucursal WHERE encargado = (data->>'idusuario')::INT)) LOOP
      FOR b IN (SELECT * FROM grupodivisa) LOOP
        SELECT compra, venta, fecha INTO c
        FROM (
          SELECT *,
            ROW_NUMBER() OVER (PARTITION BY grupoid, sucursalid ORDER BY fecha DESC) AS rn
          FROM divisas
          WHERE grupoid = b.idgrupo AND sucursalid = a.sucursalid AND fecha::DATE = CURRENT_DATE
        ) ranked
        WHERE rn = 1;

        RESULT := RESULT || JSONB_BUILD_OBJECT('sucursal', a.nombre_sucursal, 'idgrupo', b.idgrupo, 'grupo', b.grupo, 'compra', c.compra::text, 'venta', c.venta::text, 'fecharegistro', c.fecha,'sucursalid',a.sucursalid );
      END LOOP;
    END LOOP;
  ELSIF usuario = 3 THEN
    FOR a IN (SELECT * FROM sucursales WHERE sucursalid = sucursal) LOOP
      FOR b IN (SELECT * FROM grupodivisa) LOOP
        SELECT compra, venta, fecha INTO c
        FROM (
          SELECT *,
            ROW_NUMBER() OVER (PARTITION BY grupoid, sucursalid ORDER BY fecha DESC) AS rn
          FROM divisas
          WHERE grupoid = b.idgrupo AND sucursalid = a.sucursalid AND fecha::DATE = CURRENT_DATE
        ) ranked
        WHERE rn = 1;

        RESULT := RESULT || JSONB_BUILD_OBJECT('sucursal', a.nombre_sucursal, 'idgrupo', b.idgrupo, 'grupo', b.grupo, 'compra', c.compra::text, 'venta', c.venta::text, 'fecharegistro', c.fecha,'sucursalid',a.sucursalid);
      END LOOP;
    END LOOP;
  END IF;

  usuario_data := JSONB_BUILD_OBJECT('valores', RESULT);
  RETURN usuario_data;
END;
$$;


ALTER FUNCTION public.divisas_dia(data jsonb) OWNER TO geras;

--
-- Name: divisas_suc_usuario(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.divisas_suc_usuario(data jsonb) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  a RECORD;
  b RECORD;
  c RECORD;
  usuario_data JSONB;
  RESULT JSONB[] = '{}';
  usuario INT;
  sucursal INT;
BEGIN
  -- Obtener los datos del usuario activo
  SELECT
    CASE
      WHEN perfilid = 1 THEN 1
      WHEN encargado = true THEN 2
      ELSE 3
    END,
    sucursalid
  INTO
    usuario,
    sucursal
  FROM usuarios
  WHERE userid = (data->>'idusuario')::INT;

  IF usuario = 1 THEN
   
	  SELECT json_agg(row_to_json(resultado)) into usuario_data
FROM (
    SELECT idsaldos, nombre_sucursal, grupo, COALESCE(entrada, salida) as saldo, ms.fecharegistro, descripcion, entrada, salida,idsucursalid,idgrupodivisa
    FROM mov_saldos ms
    JOIN sucursales s ON ms.idsucursalid = s.sucursalid
    JOIN grupodivisa gd ON ms.idgrupodivisa = gd.idgrupo
    WHERE ms.fecharegistro::date = current_date
) resultado;
	 
  ELSIF usuario = 2 THEN
	
		 SELECT json_agg(row_to_json(resultado)) into usuario_data
FROM (
    SELECT idsaldos, nombre_sucursal, grupo, COALESCE(entrada, salida) as saldo, ms.fecharegistro, descripcion, entrada, salida,idsucursalid,idgrupodivisa
    FROM mov_saldos ms
    JOIN sucursales s ON ms.idsucursalid = s.sucursalid
    JOIN grupodivisa gd ON ms.idgrupodivisa = gd.idgrupo
    WHERE ms.fecharegistro::date = current_date
		and s.idsucursalid in ((SELECT sucursalid FROM encargadosucursal WHERE encargado = (data->>'idusuario')::INT))
) resultado;

  ELSIF usuario = 3 THEN

		 SELECT json_agg(row_to_json(resultado)) into usuario_data
FROM (
    SELECT idsaldos, nombre_sucursal, grupo, COALESCE(entrada, salida) as saldo, ms.fecharegistro, descripcion, entrada, salida,idsucursalid,idgrupodivisa
    FROM mov_saldos ms
    JOIN sucursales s ON ms.idsucursalid = s.sucursalid
    JOIN grupodivisa gd ON ms.idgrupodivisa = gd.idgrupo
    WHERE ms.fecharegistro::date = current_date
		and s.idsucursalid = sucursal
) resultado;

  END IF;

  RETURN usuario_data;
END;
$$;


ALTER FUNCTION public.divisas_suc_usuario(data jsonb) OWNER TO geras;

--
-- Name: FUNCTION divisas_suc_usuario(data jsonb); Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON FUNCTION public.divisas_suc_usuario(data jsonb) IS 'Consulta todos los datos los saldos de las divisas por tipo de usuario';


--
-- Name: divisas_sucursal(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.divisas_sucursal(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
	RESULT JSONB;

BEGIN



WITH UltimasDivisas AS (
  SELECT
    d.grupoid,
    d.iddivisa,
    d.compra,
    d.venta,
    d.fecha,
    g.grupo,
		g.tipo
  FROM
    divisas d
  INNER JOIN grupodivisa g ON d.grupoid = g.idgrupo
  WHERE
    d.sucursalid = (data ->> 'sucursal')::int
    AND d.fecha = (
      SELECT MAX(fecha)
      FROM divisas
      WHERE grupoid = d.grupoid
			and fecha::date = current_date
    )
)
SELECT
  json_agg(
    jsonb_build_object(
      'grupoid', grupoid,
      'iddivisa', iddivisa,
      'compra', compra,
      'venta', venta,
      'fecha', fecha,
      'grupo', grupo,
			'tipo', tipo
    )
  ) into RESULT
FROM
  UltimasDivisas;



	RETURN json_build_object('action', 'success', 'data', RESULT);

EXCEPTION
	WHEN OTHERS THEN
		RETURN json_build_object('action', 'error', 'message', SQLERRM);

END;
$$;


ALTER FUNCTION public.divisas_sucursal(data jsonb) OWNER TO geras;

--
-- Name: divisas_sucursales(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.divisas_sucursales(data jsonb) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  a RECORD;
  b RECORD;
  c RECORD;
  usuario_data JSONB;
  RESULT JSONB[] = '{}';
  usuario INT;
  sucursal INT;
BEGIN
  -- Obtener los datos del usuario activo
  SELECT
    CASE
      WHEN perfilid = 1 THEN 1
      WHEN encargado = true THEN 2
      ELSE 3
    END,
    sucursalid
  INTO
    usuario,
    sucursal
  FROM usuarios
  WHERE userid = (data->>'idusuario')::INT;

  IF usuario = 1 THEN
   
	 SELECT json_agg(row_to_json(consulta))  into usuario_data
FROM (
    SELECT nombre_sucursal, grupo, (ent - sal) as saldo,g.tipo
    FROM (
        SELECT idsucursalid, idgrupodivisa, sum(entrada) as ent, sum(salida) as sal
        FROM mov_saldos
        WHERE (fecharegistro)::date = current_date
        GROUP BY idgrupodivisa, idsucursalid
    ) t
    JOIN grupodivisa g ON t.idgrupodivisa = g.idgrupo
    JOIN sucursales s ON s.sucursalid = t.idsucursalid
    ORDER BY grupo, nombre_sucursal
) consulta;
	 
  ELSIF usuario = 2 THEN
	 SELECT json_agg(row_to_json(consulta))  into usuario_data
FROM (
    SELECT nombre_sucursal, grupo, (ent - sal) as saldo,g.tipo
    FROM (
        SELECT idsucursalid, idgrupodivisa, sum(entrada) as ent, sum(salida) as sal
        FROM mov_saldos
        WHERE (fecharegistro)::date = current_date
				and idsucursalid in 	(SELECT sucursalid FROM encargadosucursal WHERE encargado = (data->>'idusuario')::INT)
        GROUP BY idgrupodivisa, idsucursalid
    ) t
    JOIN grupodivisa g ON t.idgrupodivisa = g.idgrupo
    JOIN sucursales s ON s.sucursalid = t.idsucursalid
    ORDER BY grupo, nombre_sucursal
) consulta;

  ELSIF usuario = 3 THEN

		SELECT json_agg(row_to_json(consulta))  into usuario_data
FROM (
    SELECT nombre_sucursal, grupo, (ent - sal) as saldo,g.tipo
    FROM (
        SELECT idsucursalid, idgrupodivisa, sum(entrada) as ent, sum(salida) as sal
        FROM mov_saldos
        WHERE (fecharegistro)::date = current_date
				and idsucursalid = sucursal
        GROUP BY idgrupodivisa, idsucursalid
    ) t
    JOIN grupodivisa g ON t.idgrupodivisa = g.idgrupo
    JOIN sucursales s ON s.sucursalid = t.idsucursalid
    ORDER BY grupo, nombre_sucursal
) consulta;

  END IF;

  RETURN usuario_data;
END;
$$;


ALTER FUNCTION public.divisas_sucursales(data jsonb) OWNER TO geras;

--
-- Name: enviar_correo(text, text, text); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.enviar_correo(destinatario text, asunto text, mensaje text) RETURNS void
    LANGUAGE plpython3u
    AS $$
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Configuración de correo
gmail_user = 'sistemas@inmtec.net'
gmail_password = 'rixqpqyvyqsgtlsr'

# Crear mensaje
msg = MIMEMultipart()
msg['From'] = gmail_user
msg['To'] = destinatario
msg['Subject'] = asunto

msg.attach(MIMEText(mensaje, 'plain'))

# Enviar el correo
try:
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(gmail_user, gmail_password)
    server.sendmail(gmail_user, destinatario, msg.as_string())
    server.close()
except Exception as e:
    return str(e)
$$;


ALTER FUNCTION public.enviar_correo(destinatario text, asunto text, mensaje text) OWNER TO geras;

--
-- Name: login_usuario(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.login_usuario(data jsonb) RETURNS json
    LANGUAGE plpgsql
    AS $$ DECLARE
	usuario_record record;
sucursal record;
submenu record;
menu_record record;
usuario_data JSON;
menus_array JSON [];
submenus_array JSON [];
sucursales JSON [];

RESULT JSON [] = '{}';
BEGIN-- Obtener los datos del usuario activo
	SELECT
		u.userid,
		( u.nombre || ' ' || u.paterno || ' ' || u.materno ) AS nombre_usuario,
		u.calle,
		u.numero,
		cp.colonia,
		cp.municipio,
		cp.estado,
		r.idrol,
		r.descripcion AS nombre_rol,
		u.encargado,
		u.sucursalid INTO usuario_record 
	FROM
		usuarios u
		JOIN cat_dom cp ON u.idcp = cp.
		ID JOIN rol r ON u.perfilid = r.idrol 
	WHERE
		u.usuario = ( DATA ->> 'usuario' ) :: TEXT 
		AND u.contrasena = ( DATA ->> 'password' ) :: TEXT 
		AND u.activo = TRUE;
-- Si el usuario no existe o no está activo, retornar un mensaje
	IF
		usuario_record IS NULL THEN
			RETURN '{"action":"error","message": "Credenciales inválidas o usuario inactivo."}' :: JSON;
		
	END IF;
-- Obtener los menús activos asociados al rol del usuario
	FOR menu_record IN ( SELECT * FROM menusuperior )
	LOOP
	FOR submenu IN (
		SELECT M.idmenus,
			M.menu,
			M.componente 
		FROM
			accesos_rol ar
			JOIN menus M ON ar.idcomponete = M.idmenus 
		WHERE
			ar.idrol = usuario_record.idrol 
			AND M.activo = TRUE 
			AND M.idsubmenu = menu_record.idmenusuperior 
		)
		LOOP
		submenus_array := submenus_array || json_build_object ( 'submenu', submenu.idmenus, 'nombre', submenu.menu,'componente',submenu.componente );
	
END LOOP;
if submenus_array is null THEN
else
RESULT := RESULT || json_build_object ( 'menu', menu_record.descripcion, 'submenus', submenus_array );
end if;
submenus_array := null;
END LOOP;
SELECT
	e.idempresa,
	e.razonsocial,
	telefono,
	cd.cp,
	cd.colonia,
	cd.municipio,
	cd.estado,
	e.rfc,
	s.sucursalid,
	s.nombre_sucursal,
	cd1.cp AS cpsuc,
	cd1.colonia AS colsuc,
	cd1.municipio AS munsuc,
	cd1.estado AS edosuc,
	(s.calle ||' '||s.numero||', cp :'||cd1.cp||', '||cd1.colonia||', '||cd1.municipio||' '||cd1.estado) AS domicilio	
 INTO sucursal 
FROM
	empresas e
	JOIN sucursales s ON e.idempresa = s.empresaid
	JOIN cat_dom cd ON e.idcp = cd.
	ID JOIN cat_dom cd1 ON s.idcp = cd1.ID 
WHERE
	s.sucursalid = usuario_record.sucursalid;
-- Construir el JSON de respuesta
usuario_data := json_build_object (
	'usuario',
	json_build_object (
		'idusuario',
		usuario_record.userid,
		'nombre_usuario',
		usuario_record.nombre_usuario,
		'domicilio',
		( usuario_record.calle || ' ' || usuario_record.numero || ' ' || usuario_record.colonia ),
		'idrol',
		usuario_record.idrol,
		'nombre_rol',
		usuario_record.nombre_rol,
		'sucursal',
		usuario_record.sucursalid,
		'encargado',
		usuario_record.encargado 
	),
	'empresa',
	json_build_object (
		'idempresa',
		sucursal.idempresa,
		'razonsocial',
		sucursal.razonsocial,
		'telefono',
		sucursal.telefono,
		'codigo',
		sucursal.cp,
		'colonia',
		sucursal.colonia,
		'municipio',
		sucursal.municipio,
		'estado',
		sucursal.estado,
		'sucursalid',
		sucursal.sucursalid,
		'nombresucursal',
		sucursal.nombre_sucursal,
		'codigosuc',
		sucursal.cpsuc,
		'coloniasuc',
		sucursal.colsuc,
		'municipiosuc',
		sucursal.munsuc,
		'estadosuc',
		sucursal.edosuc ,
		'domicilio',
		sucursal.domicilio,
		'rfc',
		sucursal.rfc
	),
	'menus',
	result 
);
RETURN usuario_data;

END;
$$;


ALTER FUNCTION public.login_usuario(data jsonb) OWNER TO geras;

--
-- Name: manage_acceso_rol(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_acceso_rol(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ DECLARE
	RESULT JSONB;
BEGIN
	CASE
			
			WHEN ( DATA ->> 'option' ) :: INT = 1 THEN
			INSERT INTO accesos_rol ( idrol, idcomponete, status )
		VALUES
			( ( DATA ->> 'idrol' ) :: INT2, ( DATA ->> 'idcomponete' ) :: INT2, ( DATA ->> 'status' ) :: BOOL ) RETURNING idacceso INTO RESULT;
		RETURN json_build_object ( 'action', 'success', 'message', 'Acceso asociado a rol registrado correctamente', 'idacceso', RESULT );
		
		WHEN ( DATA ->> 'option' ) :: INT = 2 THEN
		UPDATE accesos_rol 
		SET idrol = ( DATA ->> 'idrol' ) :: INT2,
		idcomponete = ( DATA ->> 'idcomponete' ) :: INT2,
		status = ( DATA ->> 'status' ) :: BOOL 
		WHERE
			idacceso = ( DATA ->> 'idacceso' ) :: INT;
		IF
		FOUND THEN
				RETURN json_build_object ( 'action', 'success', 'message', 'Acceso asociado a rol actualizado correctamente' );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Acceso asociado a rol no encontrado' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 3 THEN
		DELETE 
		FROM
			accesos_rol 
		WHERE
			idacceso = ( DATA ->> 'idacceso' ) :: INT;
		IF
		FOUND THEN
				RETURN json_build_object ( 'action', 'success', 'message', 'Acceso asociado a rol eliminado correctamente' );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Acceso asociado a rol no encontrado' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 4 THEN
		SELECT
			row_to_json ( accesos_rol ) INTO RESULT 
		FROM
			accesos_rol 
		WHERE
			idacceso = ( DATA ->> 'idacceso' ) :: INT;
		IF
		RESULT IS NOT NULL THEN
				RETURN json_build_object ( 'action', 'success', 'data', RESULT );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Acceso asociado a rol no encontrado' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 5 THEN
		SELECT
			json_agg ( row_to_json ( ROW ) ) INTO RESULT 
		FROM
			(
			SELECT A
				.*,
				b.menu,
				C.descripcion 
			FROM
				accesos_rol
				A JOIN menus b ON b.idmenus :: INT = A.idcomponete ::
				INT JOIN rol C ON A.idrol = C.idrol 
			) ROW;
		RETURN json_build_object ( 'action', 'success', 'data', RESULT );
		ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Opción no válida' );
		
	END CASE;
	EXCEPTION 
	WHEN OTHERS THEN
		RETURN json_build_object ( 'action', 'error', 'message', SQLERRM );
	
END;
$$;


ALTER FUNCTION public.manage_acceso_rol(data jsonb) OWNER TO geras;

--
-- Name: manage_cat_reg(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_cat_reg(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO cat_reg (idreg, descripcion)
            VALUES (data->>'idreg', data->>'descripcion')
            RETURNING id INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Registro en cat_reg insertado correctamente', 'id', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE cat_reg
            SET idreg = data->>'idreg', descripcion = data->>'descripcion'
            WHERE id = (data->>'id')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Registro en cat_reg actualizado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Registro en cat_reg no encontrado');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM cat_reg WHERE id = (data->>'id')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Registro en cat_reg eliminado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Registro en cat_reg no encontrado');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(cat_reg) INTO result
            FROM cat_reg
            WHERE id = (data->>'id')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Registro en cat_reg no encontrado');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(cat_reg)) INTO result
            FROM cat_reg;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_cat_reg(data jsonb) OWNER TO geras;

--
-- Name: manage_cliente(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_cliente(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ DECLARE
	RESULT JSONB;
	clientesx JSONB[];
    r record;
    x record;
    RESULTS JSONB := '[]'::JSONB;
BEGIN
	CASE
			
			WHEN ( DATA ->> 'option' ) :: INT = 1 THEN
		IF
			( ( DATA ->> 'idcp' ) :: INT = 0 ) THEN
				INSERT INTO cliente (
					tipopersona,
					nombre,
					paterno,
					materno,
					idpnaci,
					estanaci,
					fechanacimiento,
					correo,
					nacionalidad,
					telefono,
					ocupacion,
					nif,
					genero,
					ididentificaion,
					nident,
					idcp,
					calle,
					colonia,
					cp,
					estado,
					municipio,
					n_ext,
					nient,
					pais 
				)
			VALUES
				(
					( DATA ->> 'tipopersona' ) :: INT,
					DATA ->> 'nombre',
					DATA ->> 'paterno',
					DATA ->> 'materno',
					( DATA ->> 'idpnaci' ) :: INT,
					( DATA ->> 'estanaci' ) :: INT,
					( DATA ->> 'fechanacimiento' ) :: DATE,
					DATA ->> 'correo',
					( DATA ->> 'nacionalidad' ) :: INT,
					DATA ->> 'telefono',
					( DATA ->> 'ocupacion' ) :: INT,
					DATA ->> 'nif',
					DATA ->> 'genero',
					( DATA ->> 'ididentificaion' ) :: INT,
					(DATA ->> 'nident')::TEXT,
					( DATA ->> 'idcp' ) :: INT,
					DATA ->> 'calle',
					DATA ->> 'colonia',
					DATA ->> 'cp',
					DATA ->> 'estado',
					DATA ->> 'municipio',
					DATA ->> 'n_ext',
					DATA ->> 'nient',
					DATA ->> 'pais' 
				) RETURNING idcliente INTO RESULT;
			ELSE INSERT INTO cliente (
				tipopersona,
				nombre,
				paterno,
				materno,
				idpnaci,
				estanaci,
				fechanacimiento,
				correo,
				curp,
				rfc,
				nacionalidad,
				telefono,
				ocupacion,
				genero,
				ididentificaion,
				nident,
				idcp, 
				calle, 
				colonia, 
				n_ext, 
				nient 
			)
			VALUES
				(
					( DATA ->> 'tipopersona' ) :: INT,
					DATA ->> 'nombre',
					DATA ->> 'paterno',
					DATA ->> 'materno',
					( DATA ->> 'idpnaci' ) :: INT,
					( DATA ->> 'estanaci' ) :: INT,
					( DATA ->> 'fechanacimiento' ) :: DATE,
					DATA ->> 'correo',
					DATA ->> 'curp',
					DATA ->> 'rfc',
					( DATA ->> 'nacionalidad' ) :: int,
					DATA ->> 'telefono',
					(DATA ->> 'ocupacion')::INT,
					DATA ->> 'genero',
					( DATA ->> 'ididentificaion' ) :: INT,
					DATA ->> 'nident',
					( DATA ->> 'idcp' ) :: INT,
					DATA ->> 'calle',
					DATA ->> 'colonia',
					DATA ->> 'n_ext',
					DATA ->> 'nient' 
				) 		RETURNING idcliente INTO RESULT;

			END IF;
		RETURN json_build_object ( 'action', 'success', 'message', 'Cliente registrado correctamente', 'idcli', RESULT );
		
		WHEN ( DATA ->> 'option' ) :: INT = 2 THEN
		IF
			( ( DATA ->> 'idcp' ) :: INT = 0 ) THEN
				UPDATE cliente 
				SET nombre = DATA ->> 'nombre',
				paterno = DATA ->> 'paterno',
				materno = DATA ->> 'materno',
				idpnaci = ( DATA ->> 'idpnaci' ) :: INT,
				estanaci = ( DATA ->> 'estanaci' ) :: INT,
				fechanacimiento = ( DATA ->> 'fechanacimiento' ) :: DATE,
				correo = DATA ->> 'correo',
				nacionalidad = ( DATA ->> 'nacionalidad' ) :: INT,
				telefono = DATA ->> 'telefono',
				ocupacion = ( DATA ->> 'ocupacion' ) :: INT,
				nif = DATA ->> 'nif',
				genero = DATA ->> 'genero',
				ididentificaion = ( DATA ->> 'ididentificaion' ) :: INT,
				nident = DATA ->> 'nident',
				idcp = ( DATA ->> 'idcp' ) :: INT,
				calle = DATA ->> 'calle',
				colonia = DATA ->> 'colonia',
				cp = DATA ->> 'cp',
				estado = DATA ->> 'estado',
				municipio = DATA ->> 'municipio',
				n_ext = DATA ->> 'n_ext',
				nient = DATA ->> 'nient',
				pais = DATA ->> 'pais' 
			WHERE
				idcliente = ( DATA ->> 'idcliente' )::int;
			ELSE UPDATE cliente 
			SET nombre = DATA ->> 'nombre',
			paterno = DATA ->> 'paterno',
			materno = DATA ->> 'materno',
			idpnaci = ( DATA ->> 'idpnaci' ) :: INT,
			estanaci = ( DATA ->> 'estanaci' ) :: INT,
			fechanacimiento = ( DATA ->> 'fechanacimiento' ) :: DATE,
			correo = DATA ->> 'correo',
			curp = DATA ->> 'curp',
			rfc = DATA ->> 'rfc',
			nacionalidad = ( DATA ->> 'nacionalidad' ) :: INT,
			telefono = DATA ->> 'telefono',
			ocupacion = ( DATA ->> 'ocupacion' ) :: INT,
			genero = DATA ->> 'genero',
			ididentificaion = ( DATA ->> 'ididentificaion' ) :: INT,
			nident = DATA ->> 'nident',
			idcp = ( DATA ->> 'idcp' ) :: INT,
			calle = DATA ->> 'calle',
			colonia = DATA ->> 'colonia',
			n_ext = DATA ->> 'n_ext',
			nient = DATA ->> 'nient' 
			WHERE
				idcliente = ( DATA ->> 'idcliente' )::int;
			
		END IF;
		IF
		FOUND THEN
				RETURN json_build_object ( 'action', 'success', 'message', 'Cliente actualizado correctamente' );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Cliente no encontrado' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 3 THEN
		DELETE 
		FROM
			cliente 
		WHERE
			idcliente = ( DATA ->> 'idcliente' ) :: INT;
		IF
		FOUND THEN
				RETURN json_build_object ( 'action', 'success', 'message', 'Cliente eliminado correctamente' );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Cliente no encontrado' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 4 THEN
		
		    FOR r IN (SELECT * FROM cliente where tipopersona = 1)
    LOOP
        clientesx = clientesx || ARRAY[jsonb_build_object(
                'idcliente', r.idcliente,
                'tipopersona', r.tipopersona,
                'nombre', r.nombre,
                'paterno', r.paterno,
                'materno', r.materno,
                'idpnaci', r.idpnaci,
                'estanaci', r.estanaci,
                'fechanacimiento', r.fechanacimiento,
                'correo', r.correo,
                'curp', r.curp,
                'rfc', r.rfc,
                'nacionalidad', r.nacionalidad,
                'telefono', r.telefono,
                'ocupacion', r.ocupacion,
                'nif', r.nif,
                'genero', r.genero,
                'ididentificaion', r.ididentificaion,
                'nident', r.nident,
                'idcp', r.idcp,
                'calle', r.calle,
                'colonia', r.colonia,
                'cp', r.cp,
                'estado', r.estado,
                'municipio', r.municipio,
                'n_ext', r.n_ext,
                'nient', r.nient,
                'pais', r.pais
            )];
    END LOOP;

    -- Segunda consulta (cliente_empresa)
    FOR x IN (SELECT * FROM cliente_empresa)
    LOOP
        clientesx = clientesx || ARRAY[jsonb_build_object(
                'nombre', x.razonsocial,
                'paterno', '',
                'materno', '',
                'telefono', x.telefono,
                'correo', '',
                'calle', x.domicilio,
                'tipopersona', '2',
                'idempresa', x.idempresa,
								  'nient',''
            )];
    END LOOP;

    -- Imprimir un mensaje en la consola
    -- Retorna el JSON resultante
    RESULTS := RESULTS || jsonb_build_object('clientes', jsonb_agg(clientesx));

    RETURN jsonb_build_object('action', 'success', 'data', RESULTS);

		WHEN ( DATA ->> 'option' ) :: INT = 5 THEN
		SELECT
			json_agg ( row_to_json ( cliente ) ) INTO RESULT 
		FROM
			cliente where tipopersona = 2 and idcliente in (
select idc from rel_emp_cli where ide = (data ->> 'idempresa')::int
);
		RETURN json_build_object ( 'action', 'success', 'data', RESULT );
		ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Opción no válida' );
		
	END CASE;
	EXCEPTION 
	WHEN OTHERS THEN
		RETURN json_build_object ( 'action', 'error', 'message', SQLERRM, 'qeu envio', DATA );
	
END;
$$;


ALTER FUNCTION public.manage_cliente(data jsonb) OWNER TO geras;

--
-- Name: manage_cliente_empresa(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_cliente_empresa(data jsonb) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  idemp int;
	RESULT int;
BEGIN
  -- Obtener los datos del usuario activo
	
	if(data->>'option')::int = 1 then 
	
	insert into cliente_empresa (razonsocial,rfc,rfcserie,nacionalidad,domicilio,telefono,correo,fechaconstitucion)VALUES(
	(data->>'razonsocial')::text,
	(data->>'rfc')::text,
	(data->>'rfcserie')::text,
	(data->>'nacionalidad')::int,
	(data->>'telefon')::text,
	(data->>'correo')::text
	(data->>'fechaconstitucion')::date) RETURNING idempresa into idemp;
	
				RETURN json_build_object('action', 'success', 'idempresa', idemp);
	end if;
	
	if(data->>'option')::int = 2 then 
		update cliente_empresa SET
		razonsocial = (data->>'razonsocial')::text,
		rfc =	(data->>'rfc')::text,
		rfcserie = 	(data->>'rfcserie')::text,
		nacionalidad=	(data->>'nacionalidad')::int,
		domicilio = (data->>'domicilio')::text
		where idempresa = (data->>'idempresa')::int;

	
	end if;

	if(data->>'option')::int = 3 then 
			IF
			( ( DATA ->> 'idcp' ) :: INT = 0 ) THEN
				INSERT INTO cliente (
					tipopersona,
					nombre,
					paterno,
					materno,
					idpnaci,
					estanaci,
					fechanacimiento,
					correo,
					nacionalidad,
					telefono,
					ocupacion,
					nif,
					genero,
					ididentificaion,
					nident,
					idcp,
					calle,
					colonia,
					cp,
					estado,
					municipio,
					n_ext,
					nient,
					pais 
				)
			VALUES
				(
					( DATA ->> 'tipopersona' ) :: INT,
					DATA ->> 'nombre',
					DATA ->> 'paterno',
					DATA ->> 'materno',
					( DATA ->> 'idpnaci' ) :: INT,
					( DATA ->> 'estanaci' ) :: INT,
					( DATA ->> 'fechanacimiento' ) :: DATE,
					DATA ->> 'correo',
					( DATA ->> 'nacionalidad' ) :: INT,
					DATA ->> 'telefono',
					( DATA ->> 'ocupacion' ) :: INT,
					DATA ->> 'nif',
					DATA ->> 'genero',
					( DATA ->> 'ididentificaion' ) :: INT,
					(DATA ->> 'nident')::TEXT,
					( DATA ->> 'idcp' ) :: INT,
					DATA ->> 'calle',
					DATA ->> 'colonia',
					DATA ->> 'cp',
					DATA ->> 'estado',
					DATA ->> 'municipio',
					DATA ->> 'n_ext',
					DATA ->> 'nient',
					DATA ->> 'pais' 
				) RETURNING idcliente INTO RESULT;
			ELSE INSERT INTO cliente (
				tipopersona,
				nombre,
				paterno,
				materno,
				idpnaci,
				estanaci,
				fechanacimiento,
				correo,
				curp,
				rfc,
				nacionalidad,
				telefono,
				ocupacion,
				genero,
				ididentificaion,
				nident,
				idcp, 
				calle, 
				colonia, 
				n_ext, 
				nient 
			)
			VALUES
				(
					( DATA ->> 'tipopersona' ) :: INT,
					DATA ->> 'nombre',
					DATA ->> 'paterno',
					DATA ->> 'materno',
					( DATA ->> 'idpnaci' ) :: INT,
					( DATA ->> 'estanaci' ) :: INT,
					( DATA ->> 'fechanacimiento' ) :: DATE,
					DATA ->> 'correo',
					DATA ->> 'curp',
					DATA ->> 'rfc',
					( DATA ->> 'nacionalidad' ) :: int,
					DATA ->> 'telefono',
					(DATA ->> 'ocupacion')::INT,
					DATA ->> 'genero',
					( DATA ->> 'ididentificaion' ) :: INT,
					DATA ->> 'nident',
					( DATA ->> 'idcp' ) :: INT,
					DATA ->> 'calle',
					DATA ->> 'colonia',
					DATA ->> 'n_ext',
					DATA ->> 'nient' 
				) 		RETURNING idcliente INTO RESULT;

			END IF;

			insert into rel_emp_cli(idc,ide) VALUES(
			RESULT,(data->>'idempresa')::int   
			);
			RETURN json_build_object ( 'action', 'success', 'message', 'Cliente registrado correctamente');

	end if;
	EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);

END;
$$;


ALTER FUNCTION public.manage_cliente_empresa(data jsonb) OWNER TO geras;

--
-- Name: manage_divisa(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_divisa(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO divisas ( grupoid, compra, venta, fecha, sucursalid)
            VALUES ( (data->>'grupoid')::int2, (data->>'compra')::numeric, (data->>'venta')::numeric,CURRENT_TIMESTAMP,(data->> 'sucursal')::int )
            RETURNING iddivisa INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Divisa registrada correctamente', 'iddivisa', result);
        
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_divisa(data jsonb) OWNER TO geras;

--
-- Name: manage_empresa(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_empresa(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ DECLARE
	RESULT JSONB;
BEGIN
	CASE
			
			WHEN ( DATA ->> 'option' ) :: INT = 1 THEN
			INSERT INTO empresas ( razonsocial, rfc, calle, numero, idcp, idpais, telefono, idregimenfiscal, fechainicioop, emailoc, avisoprivasidad, activo, fechacierre )
		VALUES
			(
				DATA ->> 'razonsocial',
				DATA ->> 'rfc',
				DATA ->> 'calle',
				DATA ->> 'numero',
				( DATA ->> 'idcp' ) :: INT,
				( DATA ->> 'idpais' ) :: INT,
				( DATA ->> 'telefono' ) :: TEXT,
				( DATA ->> 'idregimenfiscal' ) :: INT,
				( DATA ->> 'fechainicioop' ) :: DATE,
				DATA ->> 'emailoc',
				DATA ->> 'avisoprivasidad',
				( DATA ->> 'activo' ) :: BOOL,
				( DATA ->> 'fechacierre' ) :: DATE 
			) RETURNING idempresa INTO RESULT;
		RETURN json_build_object ( 'action', 'success', 'message', 'Empresa registrada correctamente', 'idempresa', RESULT );
		
		WHEN ( DATA ->> 'option' ) :: INT = 2 THEN
		UPDATE empresas 
		SET razonsocial = DATA ->> 'razonsocial',
		rfc = DATA ->> 'rfc',
		calle = DATA ->> 'calle',
		numero = DATA ->> 'numero',
		idcp = ( DATA ->> 'idcp' ) :: INT,
		idpais = ( DATA ->> 'idpais' ) :: INT,
		telefono = ( DATA ->> 'telefono' ) :: TEXT,
		idregimenfiscal = ( DATA ->> 'idregimenfiscal' ) :: INT,
		fechainicioop = ( DATA ->> 'fechainicioop' ) :: DATE,
		emailoc = DATA ->> 'emailoc',
		avisoprivasidad = DATA ->> 'avisoprivasidad',
		activo = ( DATA ->> 'activo' ) :: BOOL 
		WHERE
			idempresa = ( DATA ->> 'idempresa' ) :: INT;
		IF
		FOUND THEN
				RETURN json_build_object ( 'action', 'success', 'message', 'Empresa actualizada correctamente' );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Empresa no encontrada' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 3 THEN
		DELETE 
		FROM
			empresas 
		WHERE
			idempresa = ( DATA ->> 'idempresa' ) :: INT;
		IF
		FOUND THEN
				RETURN json_build_object ( 'action', 'success', 'message', 'Empresa eliminada correctamente' );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Empresa no encontrada' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 4 THEN
		SELECT
			row_to_json ( empresas ) INTO RESULT 
		FROM
			empresas 
		WHERE
			idempresa = ( DATA ->> 'idempresa' ) :: INT;
		IF
		RESULT IS NOT NULL THEN
				RETURN json_build_object ( 'action', 'success', 'data', RESULT );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Empresa no encontrada' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 5 THEN
		SELECT
			json_agg ( row_to_json ( empresas ) ) INTO RESULT 
		FROM
			empresas;
		RETURN json_build_object ( 'action', 'success', 'data', RESULT );
		ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Opción no válida' );
		
	END CASE;
	EXCEPTION 
	WHEN OTHERS THEN
		RETURN json_build_object ( 'action', 'error', 'message', SQLERRM );
	
END;
$$;


ALTER FUNCTION public.manage_empresa(data jsonb) OWNER TO geras;

--
-- Name: manage_encargados(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_encargados(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ DECLARE
	RESULT JSONB;
BEGIN
	CASE
			
			WHEN ( DATA ->> 'option' ) :: INT = 1 THEN
			INSERT INTO encargadosucursal (
				encargado,
				sucursalid
			)
		VALUES
			(
				(DATA ->> 'idusuario')::int,
				(DATA ->> 'sucursalid')::int
			
			); 
			RETURN json_build_object('action', 'success', 'message', 'Se Registro correctamente ');
			
		WHEN ( DATA ->> 'option' ) :: INT = 2 THEN
		DELETE 
		FROM
			encargadosucursal 
		WHERE
			idenc = ( DATA ->> 'idencargado' ) :: INT;
		RESULT := '{"action": "success", "message": "eliminado correctamente"}' :: JSONB;
		
		
		ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Opción no válida' );
		
	END CASE;
	RETURN RESULT;
	EXCEPTION 
	WHEN OTHERS THEN
		RESULT := json_build_object ( 'action', 'error', 'message', SQLERRM );
	RETURN RESULT;
	
END;
$$;


ALTER FUNCTION public.manage_encargados(data jsonb) OWNER TO geras;

--
-- Name: manage_grupo_divisa(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_grupo_divisa(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO grupodivisa (grupo, riesgo)
            VALUES (data->>'grupo', (data->>'riesgo')::bool)
            RETURNING idgrupo INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Grupo de divisa registrado correctamente', 'idgrupo', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE grupodivisa
            SET grupo = data->>'grupo', riesgo = (data->>'riesgo')::bool
            WHERE idgrupo = (data->>'idgrupo')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Grupo de divisa actualizado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Grupo de divisa no encontrado');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM grupodivisa WHERE idgrupo = (data->>'idgrupo')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Grupo de divisa eliminado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Grupo de divisa no encontrado');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(grupodivisa) INTO result
            FROM grupodivisa
            WHERE idgrupo = (data->>'idgrupo')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Grupo de divisa no encontrado');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(grupodivisa)) INTO result
            FROM grupodivisa;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_grupo_divisa(data jsonb) OWNER TO geras;

--
-- Name: manage_identificacion(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_identificacion(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO cat_identificacion (descripcion)
            VALUES (data->>'descripcion')
            RETURNING ididentificacion INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Identificación registrada correctamente', 'ididentificacion', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE cat_identificacion
            SET descripcion = data->>'descripcion'
            WHERE ididentificacion = (data->>'ididentificacion')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Identificación actualizada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Identificación no encontrada');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM cat_identificacion WHERE ididentificacion = (data->>'ididentificacion')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Identificación eliminada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Identificación no encontrada');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(cat_identificacion) INTO result
            FROM cat_identificacion
            WHERE ididentificacion = (data->>'ididentificacion')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Identificación no encontrada');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(cat_identificacion)) INTO result
            FROM cat_identificacion;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_identificacion(data jsonb) OWNER TO geras;

--
-- Name: manage_menu(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_menu(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO menus (menu, componente, activo)
            VALUES (data->>'menu', data->>'componente', (data->>'activo')::bool)
            RETURNING idmenus INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Menú registrado correctamente', 'idmenus', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE menus
            SET menu = data->>'menu', componente = data->>'componente', activo = (data->>'activo')::bool
            WHERE idmenus = (data->>'idmenus')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Menú actualizado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Menú no encontrado');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM menus WHERE idmenus = (data->>'idmenus')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Menú eliminado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Menú no encontrado');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(menus) INTO result
            FROM menus
            WHERE idmenus = (data->>'idmenus')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Menú no encontrado');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(menus)) INTO result
            FROM menus;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_menu(data jsonb) OWNER TO geras;

--
-- Name: manage_nacionalidad(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_nacionalidad(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO cat_nacionalidad (nacionalidad)
            VALUES (data->>'nacionalidad')
            RETURNING idnaci INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Nacionalidad registrada correctamente', 'idnaci', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE cat_nacionalidad
            SET nacionalidad = data->>'nacionalidad'
            WHERE idnaci = (data->>'idnaci')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Nacionalidad actualizada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Nacionalidad no encontrada');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM cat_nacionalidad WHERE idnaci = (data->>'idnaci')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Nacionalidad eliminada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Nacionalidad no encontrada');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(cat_nacionalidad) INTO result
            FROM cat_nacionalidad
            WHERE idnaci = (data->>'idnaci')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Nacionalidad no encontrada');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(cat_nacionalidad)) INTO result
            FROM cat_nacionalidad;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_nacionalidad(data jsonb) OWNER TO geras;

--
-- Name: manage_ocupacion(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_ocupacion(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO cat_ocupaciones (descripcion, claveof, nivel)
            VALUES (data->>'descripcion', data->>'claveof', (data->>'nivel')::bool)
            RETURNING idacividad INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Ocupación registrada correctamente', 'idacividad', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE cat_ocupaciones
            SET descripcion = data->>'descripcion', claveof = data->>'claveof', nivel = (data->>'nivel')::bool
            WHERE idacividad = (data->>'idacividad')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Ocupación actualizada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Ocupación no encontrada');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM cat_ocupaciones WHERE idacividad = (data->>'idacividad')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Ocupación eliminada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Ocupación no encontrada');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(cat_ocupaciones) INTO result
            FROM cat_ocupaciones
            WHERE idacividad = (data->>'idacividad')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Ocupación no encontrada');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(cat_ocupaciones)) INTO result
            FROM cat_ocupaciones;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_ocupacion(data jsonb) OWNER TO geras;

--
-- Name: manage_operaciones(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_operaciones(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ DECLARE
	RESULT JSONB;
BEGIN
		INSERT INTO mov_divisas ( tipo, grupoid, mn, me, sucursalid, usuarioid, clienteid, fecharegistro, tipocambio )
	VALUES
		(
			( DATA ->> 'tipo' ) :: INT,
			( DATA ->> 'grupoid' ) :: INT,
			( DATA ->> 'mn' ) :: NUMERIC,
			( DATA ->> 'me' ) :: NUMERIC,
			( DATA ->> 'sucursalid' ) :: INT,
			( DATA ->> 'usuarioid' ) :: INT,
			( DATA ->> 'clienteid' ) :: INT,
			CURRENT_TIMESTAMP,
			( DATA ->> 'tipocambio' ) :: NUMERIC 
		)
	RETURNING idmovimiento INTO RESULT;
	IF
		( ( DATA ->> 'tipo' ) :: INT = 1 ) THEN
			INSERT INTO mov_saldos ( idsucursalid, idgrupodivisa, entrada, salida, idusuario, tipo, fecharegistro, descripcion )
		VALUES
			(
				( DATA ->> 'sucursalid' ) :: INT,
				( DATA ->> 'grupoid' ) :: INT,
				( DATA ->> 'me' ) :: NUMERIC,
				0.00,
				( DATA ->> 'usuarioid' ) :: INT,
				2,
				CURRENT_TIMESTAMP,
				'Compra de divisa' 
			);
		INSERT INTO mov_saldos ( idsucursalid, idgrupodivisa, entrada, salida, idusuario, tipo, fecharegistro, descripcion )
		VALUES
			(
				( DATA ->> 'sucursalid' ) :: INT,
				1,
				0.00,
				( DATA ->> 'mn' ) :: NUMERIC,
				( DATA ->> 'usuarioid' ) :: INT,
				2,
				CURRENT_TIMESTAMP,
				'Compra de divisa' 
			);
		ELSE 
		INSERT INTO mov_saldos ( idsucursalid, idgrupodivisa, entrada, 
		salida, idusuario, tipo, fecharegistro, descripcion )
		VALUES
			(
				( DATA ->> 'sucursalid' ) :: INT,
				( DATA ->> 'grupoid' ) :: INT,
				0.00,
				( DATA ->> 'me' ) :: NUMERIC,
				( DATA ->> 'usuarioid' ) :: INT,
				3,
				CURRENT_TIMESTAMP,
				'Venta de divisa' 
			);
		INSERT INTO mov_saldos ( idsucursalid, idgrupodivisa, entrada, 
		salida, idusuario, tipo, fecharegistro, descripcion )
		VALUES
			(
				( DATA ->> 'sucursalid' ) :: INT,
				1,
				( DATA ->> 'mn' ) :: NUMERIC,
				0.00,
				( DATA ->> 'usuarioid' ) :: INT,
				3,
				CURRENT_TIMESTAMP,
				'Venta de divisa' 
			);
		
	END IF;
	RETURN json_build_object ( 'action', 'success', 'operacion', RESULT );
	EXCEPTION 
	WHEN OTHERS THEN
		RETURN json_build_object ( 'action', 'error', 'message', SQLERRM );
	
END;
$$;


ALTER FUNCTION public.manage_operaciones(data jsonb) OWNER TO geras;

--
-- Name: manage_rol(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_rol(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO rol (descripcion)
            VALUES (data->>'descripcion')
            RETURNING idrol INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Rol registrado correctamente', 'idrol', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE rol
            SET descripcion = data->>'descripcion'
            WHERE idrol = (data->>'idrol')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Rol actualizado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Rol no encontrado');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM rol WHERE idrol = (data->>'idrol')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Rol eliminado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Rol no encontrado');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(rol) INTO result
            FROM rol
            WHERE idrol = (data->>'idrol')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Rol no encontrado');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(rol)) INTO result
            FROM rol;
            RETURN json_build_object('action', 'success', 'data', result);
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_rol(data jsonb) OWNER TO geras;

--
-- Name: manage_saldo_dvisas(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_saldo_dvisas(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO mov_saldos (idsucursalid, idgrupodivisa,entrada,salida,idusuario,tipo,fecharegistro,descripcion)
            VALUES ((data->>'idsucursalid')::int,(data->>'idgrupodivisa')::int,(data->>'entrada')::numeric,(data->>'salida')::numeric,(data->>'idusuario')::int,(data->>'tipo')::int,CURRENT_TIMESTAMP,(data->>'descripcion'))
            RETURNING idsaldos INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Registro en cat_reg insertado correctamente', 'id', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE mov_saldos
            SET  entrada = (data->>'entrada')::numeric,salida  = (data->>'salida')::numeric , idusuario = (data->>'idusuario')::int , descripcion = (data->>'descripcion')
            WHERE idsaldos = (data->>'idsaldos')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Registro en cat_reg actualizado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Registro en cat_reg no encontrado');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM mov_saldos WHERE idsaldos = (data->>'idsaldos')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Registro en cat_reg eliminado correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Registro en cat_reg no encontrado');
            END IF;
        
        ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_saldo_dvisas(data jsonb) OWNER TO geras;

--
-- Name: manage_sucursal(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_sucursal(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    CASE 
        WHEN (data->>'option')::int = 1 THEN
            INSERT INTO sucursales (nombre_sucursal, calle, numero, idcp, fecharegistro, activa, empresaid)
            VALUES (data->>'nombre_sucursal', data->>'calle', data->>'numero', (data->>'idcp')::int, (data->>'fecharegistro')::date, (data->>'activa')::bool, (data->>'empresaid')::int)
            RETURNING sucursalid INTO result;
            RETURN json_build_object('action', 'success', 'message', 'Sucursal registrada correctamente', 'sucursalid', result);
        WHEN (data->>'option')::int = 2 THEN
            UPDATE sucursales
            SET nombre_sucursal = data->>'nombre_sucursal', calle = data->>'calle', numero = data->>'numero', idcp = (data->>'idcp')::int, fecharegistro = (data->>'fecharegistro')::date, activa = (data->>'activa')::bool, empresaid = (data->>'empresaid')::int2
            WHERE sucursalid = (data->>'sucursalid')::int;
            
            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Sucursal actualizada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Sucursal no encontrada');
            END IF;
        WHEN (data->>'option')::int = 3 THEN
            DELETE FROM sucursales WHERE sucursalid = (data->>'sucursalid')::int;

            IF FOUND THEN
                RETURN json_build_object('action', 'success', 'message', 'Sucursal eliminada correctamente');
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Sucursal no encontrada');
            END IF;
        WHEN (data->>'option')::int = 4 THEN
            SELECT row_to_json(sucursales) INTO result
            FROM sucursales
            WHERE sucursalid = (data->>'sucursalid')::int;

            IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'Sucursal no encontrada');
            END IF;
        WHEN (data->>'option')::int = 5 THEN
            SELECT json_agg(row_to_json(sucursales)) INTO result
            FROM sucursales;
            RETURN json_build_object('action', 'success', 'data', result);
         WHEN (data->>'option')::int = 6 THEN
            SELECT json_agg(row_to_json(sucursales)) INTO result
            FROM sucursales
            WHERE empresaid = (data->>'empresaid')::int;
						IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'La Empresa no tiene sucursales');
            END IF;   
				WHEN (data->>'option')::int = 7 THEN
            SELECT json_agg(row_to_json(sucursales)) INTO result
            FROM sucursales
            WHERE sucursalid in (select sucurusalid from encargadosucursal where encargado = (data->>'userid')::int);
						IF result IS NOT NULL THEN
                RETURN json_build_object('action', 'success', 'data', result);
            ELSE
                RETURN json_build_object('action', 'error', 'message', 'La Empresa no tiene sucursales');
            END IF; 
				ELSE
            RETURN json_build_object('action', 'error', 'message', 'Opción no válida');
    END CASE;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.manage_sucursal(data jsonb) OWNER TO geras;

--
-- Name: manage_user(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.manage_user(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$ DECLARE
	RESULT JSONB;
BEGIN
	CASE
			
			WHEN ( DATA ->> 'option' ) :: INT = 1 THEN
			INSERT INTO usuarios (
				usuario,
				contrasena,
				nombre,
				paterno,
				materno,
				calle,
				numero,
				idcp,
				correo,
				telefono,
				activo,
				fecharegistro,
				usuariomodifico,
				fechamodificacion,
				perfilid,
				sucursalid,
				encargado 
			)
		VALUES
			(
				DATA ->> 'usuario',
				DATA ->> 'contrasena',
				DATA ->> 'nombre',
				DATA ->> 'paterno',
				DATA ->> 'materno',
				DATA ->> 'calle',
				DATA ->> 'numero',
				( DATA ->> 'idcp' ) :: INT,
				DATA ->> 'correo',
				DATA ->> 'telefono',
				( DATA ->> 'activo' ) :: BOOL,
				( DATA ->> 'fecharegistro' ) :: DATE,
				DATA ->> 'usuariomodifico',
				( DATA ->> 'fechamodificacion' ) :: DATE,
				( DATA ->> 'perfilid' ) :: INT,
				( DATA ->> 'sucursalid' ) :: INT ,
				(DATA ->> 'encargado')::bool
			); 
			RETURN json_build_object('action', 'success', 'message', 'Se Registro correctamente ');
			
			
		
		WHEN ( DATA ->> 'option' ) :: INT = 2 THEN
		UPDATE usuarios 
		SET usuario = DATA ->> 'usuario',
		contrasena = DATA ->> 'contrasena',
		nombre = DATA ->> 'nombre',
		paterno = DATA ->> 'paterno',
		materno = DATA ->> 'materno',
		calle = DATA ->> 'calle',
		numero = DATA ->> 'numero',
		idcp = ( DATA ->> 'idcp' ) :: INT,
		correo = DATA ->> 'correo',
		telefono = DATA ->> 'telefono',
		activo = ( DATA ->> 'activo' ) :: BOOL,
		fecharegistro = ( DATA ->> 'fecharegistro' ) :: DATE,
		usuariomodifico = DATA ->> 'usuariomodifico',
		fechamodificacion = ( DATA ->> 'fechamodificacion' ) :: DATE,
		perfilid = ( DATA ->> 'perfilid' ) :: INT,
		sucursalid = ( DATA ->> 'sucursalid' ) :: INT,
		encargado = (DATA ->> 'encargado')::bool
		WHERE
			userid = ( DATA ->> 'userid' ) :: INT;
		RESULT := '{"action": "success", "message": "Usuario actualizado correctamente"}' :: JSONB;
		
		WHEN ( DATA ->> 'option' ) :: INT = 3 THEN
		DELETE 
		FROM
			usuarios 
		WHERE
			userid = ( DATA ->> 'userid' ) :: INT;
		RESULT := '{"action": "success", "message": "Usuario eliminado correctamente"}' :: JSONB;
		
		WHEN ( DATA ->> 'option' ) :: INT = 4 THEN
		SELECT
			row_to_json ( usuarios ) INTO RESULT 
		FROM
			usuarios 
		WHERE
			userid = ( DATA ->> 'userid' ) :: INT;
		IF
		RESULT IS NOT NULL THEN
				RETURN json_build_object ( 'action', 'success', 'data', RESULT );
			ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Cliente no encontrado' );
			
		END IF;
		
		WHEN ( DATA ->> 'option' ) :: INT = 5 THEN
		SELECT
			json_agg ( row_to_json ( usuarios ) ) INTO RESULT 
		FROM
			usuarios;
		RETURN json_build_object ( 'action', 'success', 'data', RESULT );
		WHEN ( DATA ->> 'option' ) :: INT = 6 THEN
		SELECT
			json_agg ( row_to_json ( usuarios ) ) INTO RESULT 
		FROM
			usuarios where encargado = true;
		RETURN json_build_object ( 'action', 'success', 'data', RESULT );
		ELSE RETURN json_build_object ( 'action', 'error', 'message', 'Opción no válida' );
		
	END CASE;
	RETURN RESULT;
	EXCEPTION 
	WHEN OTHERS THEN
		RESULT := json_build_object ( 'action', 'error', 'message', SQLERRM );
	RETURN RESULT;
	
END;
$$;


ALTER FUNCTION public.manage_user(data jsonb) OWNER TO geras;

--
-- Name: obtenerdatosclientes(); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.obtenerdatosclientes() RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    clientesx JSONB[];
    r record;
    x record;
    RESULT JSONB := '[]'::JSONB;
BEGIN
    -- Primera consulta (cliente)
    FOR r IN (SELECT * FROM cliente)
    LOOP
        clientesx = clientesx || ARRAY[jsonb_build_object(
                'idcliente', r.idcliente,
                'tipopersona', r.tipopersona,
                'nombre', r.nombre,
                'paterno', r.paterno,
                'materno', r.materno,
                'idpnaci', r.idpnaci,
                'estanaci', r.estanaci,
                'fechanacimiento', r.fechanacimiento,
                'correo', r.correo,
                'curp', r.curp,
                'rfc', r.rfc,
                'nacionalidad', r.nacionalidad,
                'telefono', r.telefono,
                'ocupacion', r.ocupacion,
                'nif', r.nif,
                'genero', r.genero,
                'ididentificaion', r.ididentificaion,
                'nident', r.nident,
                'idcp', r.idcp,
                'calle', r.calle,
                'colonia', r.colonia,
                'cp', r.cp,
                'estado', r.estado,
                'municipio', r.municipio,
                'n_ext', r.n_ext,
                'nient', r.nient,
                'pais', r.pais
            )];
    END LOOP;

    -- Segunda consulta (cliente_empresa)
    FOR x IN (SELECT * FROM cliente_empresa)
    LOOP
        clientesx = clientesx || ARRAY[jsonb_build_object(
                'nombre', x.razonsocial,
                'paterno', '',
                'materno', '',
                'telefono', '',
                'correo', '',
                'calle', x.domicilio,
                'tipopersona', 2,
                'idempresa', x.idempresa
            )];
    END LOOP;

    -- Imprimir un mensaje en la consola
    RAISE NOTICE 'Mensaje de prueba';

    -- Retorna el JSON resultante
    RESULT := RESULT || jsonb_build_object('usuarios', jsonb_agg(clientesx));

    RETURN jsonb_build_object('action', 'success', 'data', RESULT);
END;
$$;


ALTER FUNCTION public.obtenerdatosclientes() OWNER TO geras;

--
-- Name: saldosdia(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.saldosdia(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    RESULT JSONB := '[]'::jsonb;
    r record;
BEGIN
for r in 
  select (SUM(entrada) - SUM(salida)) AS saldosfinales,
        idgrupodivisa,
        idsucursalid
    FROM
        mov_saldos
    WHERE
        fecharegistro::date = current_date
				and idgrupodivisa = (data ->> 'tdivisa')::int
				and idsucursalid = (data ->> 'sucursal')::int
    GROUP BY
        idgrupodivisa,
        idsucursalid
	LOOP
	return jsonb_build_object('saldosfinales', r.saldosfinales, 'idgrupodivisa', r.idgrupodivisa, 'idsucursalid', r.idsucursalid);
END LOOP;
			
			
EXCEPTION 
WHEN OTHERS THEN
   
    RETURN json_build_object('action', 'error', 'message', SQLERRM);

END;
$$;


ALTER FUNCTION public.saldosdia(data jsonb) OWNER TO geras;

--
-- Name: saldosiniciales(); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.saldosiniciales() RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    RESULT JSONB := '[]'::jsonb;
    r record;
BEGIN
    FOR r IN SELECT
        (SUM(entrada) - SUM(salida)) AS saldosfinales,
        idgrupodivisa,
        idsucursalid
    FROM
        mov_saldos
    WHERE
        fecharegistro::date = current_date - 1
    GROUP BY
        idgrupodivisa,
        idsucursalid
    LOOP
        RESULT = RESULT || jsonb_build_object('saldosfinales', r.saldosfinales, 'idgrupodivisa', r.idgrupodivisa, 'idsucursalid', r.idsucursalid);

        INSERT INTO mov_saldos (idsucursalid, idgrupodivisa, entrada, salida, idusuario, tipo,descripcion, fecharegistro)
        VALUES (r.idsucursalid, r.idgrupodivisa, r.saldosfinales, 0, 1,1, 'Tarea de saldo iniciales por divisa', CURRENT_TIMESTAMP);
    END LOOP;

    PERFORM enviar_correo('sistemas@inmtec.net', 'Tarea Programada Creacion de saldos iniciales para el dia ' || CURRENT_TIMESTAMP, jsonb_pretty(RESULT));
RETURN json_build_object('action', 'success', 'message', 'Tarea completada');

EXCEPTION 
WHEN OTHERS THEN
    PERFORM enviar_correo('sistemas@inmtec.net', 'Tarea Programada Creacion de saldos iniciales para el dia ' || CURRENT_TIMESTAMP || ' fallo', SQLERRM);
    RETURN json_build_object('action', 'error', 'message', SQLERRM);

END;
$$;


ALTER FUNCTION public.saldosiniciales() OWNER TO geras;

--
-- Name: search_by_cp(text); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.search_by_cp(cp_to_search text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    SELECT json_agg(row_to_json(cat_dom)) INTO result
    FROM cat_dom
    WHERE cp LIKE '%' || cp_to_search || '%';

    IF result IS NOT NULL THEN
        RETURN json_build_object('action', 'success', 'data', result);
    ELSE
        RETURN json_build_object('action', 'error', 'message', 'El codigo postal '||cp_to_search||' no encontro registros');
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.search_by_cp(cp_to_search text) OWNER TO geras;

--
-- Name: search_by_cp_id(integer); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.search_by_cp_id(cp_to_search integer) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    result jsonb;
BEGIN
    SELECT json_agg(row_to_json(cat_dom)) INTO result
    FROM cat_dom
    WHERE id =  cp_to_search;

    IF result IS NOT NULL THEN
        RETURN json_build_object('action', 'success', 'data', result);
    ELSE
        RETURN json_build_object('action', 'error', 'message', 'El codigo postal '||cp_to_search||' no encontro registros');
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('action', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.search_by_cp_id(cp_to_search integer) OWNER TO geras;

--
-- Name: valida_formulario(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.valida_formulario(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
	RESULT JSONB;
	tipoc NUMERIC;
	valor NUMERIC;
BEGIN
	SELECT dato::numeric INTO tipoc
	FROM tipo_cambio
	WHERE fecha = (SELECT MAX(fecha) FROM tipo_cambio);

	SELECT (data->>'info')::numeric / tipoc::numeric INTO valor;

RAISE NOTICE 'El valor de la variable "valor" es: %', valor;


	CASE
		WHEN valor >= 1 AND valor <= 999 THEN
			RESULT := json_build_object (
				'info', 1,
				'formulario', json_build_object (
					'nombres', TRUE,
					'paterno', TRUE,
					'materno', TRUE,
					'paisnaci', TRUE,
					'estanaci', TRUE,
					'nacionalidad', TRUE,
					'fechanacimiento', TRUE,
					'identificacion', FALSE,
					'numerodeidentificacion', FALSE,
					'genero', TRUE,
					'ocupacion', FALSE,
					'numerotelefono', TRUE,
					'correoelectronico', FALSE,
					'curp', FALSE,
					'rfc', FALSE,
					'numeroidentificacionfiscal', FALSE,
					'pais', FALSE,
					'cp', TRUE,
					'calle', TRUE,
					'numerointerior', FALSE,
					'numeroexterior', FALSE,
					'idcp', TRUE,
					'colonia', TRUE,
					'municipio', TRUE,
					'estado', TRUE,
					'pais_', TRUE
				)
			);
		WHEN valor >= 1000 AND valor <= 2099 THEN
			RESULT := json_build_object (
				'info', 'consultar',
				'formulario', json_build_object (
					'nombres', TRUE,
					'paterno', TRUE,
					'materno', TRUE,
					'paisnaci', TRUE,
					'estanaci', TRUE,
					'nacionalidad', TRUE,
					'fechanacimiento', TRUE,
					'identificacion', FALSE,
					'numerodeidentificacion', FALSE,
					'genero', TRUE,
					'ocupacion', FALSE,
					'numerotelefono', TRUE,
					'correoelectronico', FALSE,
					'curp', FALSE,
					'rfc', FALSE,
					'numeroidentificacionfiscal', FALSE,
					'pais', FALSE,
					'cp', TRUE,
					'calle', TRUE,
					'numerointerior', FALSE,
					'numeroexterior', FALSE,
					'idcp', TRUE,
					'colonia', TRUE,
					'municipio', TRUE,
					'estado', TRUE,
					'pais_', TRUE
				)
			);
		WHEN valor >= 3000 AND valor <= 4999 THEN
			RESULT := json_build_object (
				'info', 'consultar',
				'formulario', json_build_object (
					'nombres', TRUE,
					'paterno', TRUE,
					'materno', TRUE,
					'paisnaci', TRUE,
					'estanaci', TRUE,
					'nacionalidad', TRUE,
					'fechanacimiento', TRUE,
					'identificacion', FALSE,
					'numerodeidentificacion', FALSE,
					'genero', TRUE,
					'ocupacion', FALSE,
					'numerotelefono', TRUE,
					'correoelectronico', FALSE,
					'curp', FALSE,
					'rfc', FALSE,
					'numeroidentificacionfiscal', FALSE,
					'pais', FALSE,
					'cp', TRUE,
					'calle', TRUE,
					'numerointerior', FALSE,
					'numeroexterior', FALSE,
					'idcp', TRUE,
					'colonia', TRUE,
					'municipio', TRUE,
					'estado', TRUE,
					'pais_', TRUE
				)
			);
		WHEN valor >= 5000 AND valor <= 10000 THEN
			RESULT := json_build_object (
				'info', 'consulta',
				'formulario', json_build_object (
					'nombres', TRUE,
					'paterno', TRUE,
					'materno', TRUE,
					'paisnaci', TRUE,
					'estanaci', TRUE,
					'nacionalidad', TRUE,
					'fechanacimiento', TRUE,
					'identificacion', TRUE,
					'numerodeidentificacion', TRUE,
					'genero', TRUE,
					'ocupacion', TRUE,
					'numerotelefono', TRUE,
					'correoelectronico', TRUE,
					'curp', TRUE,
					'rfc', TRUE,
					'numeroidentificacionfiscal', TRUE,
					'pais', TRUE,
					'cp', TRUE,
					'calle', TRUE,
					'numerointerior', TRUE,
					'numeroexterior', TRUE,
					'idcp', TRUE,
					'colonia', TRUE,
					'municipio', TRUE,
					'estado', TRUE,
					'pais_', TRUE
				)
			);
		when valor > 10000 then
			RESULT := 'Supera el límite de los 10,000 dólares de acuerdo al tipo de cambio';
		ELSE
			RESULT := '';
	END CASE;

	RETURN json_build_object('action', 'success', 'data', RESULT);

EXCEPTION
	WHEN OTHERS THEN
		RETURN json_build_object('action', 'error', 'message', SQLERRM);

END;
$$;


ALTER FUNCTION public.valida_formulario(data jsonb) OWNER TO geras;

--
-- Name: validar_divisas(jsonb); Type: FUNCTION; Schema: public; Owner: geras
--

CREATE FUNCTION public.validar_divisas(data jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    usuario_record record;
    r record;
    x record;
    usuario_data JSON;
    menus_array JSON [];
    submenus_array JSON [];
    sucursales JSON [];
  usuario INT;

    RESULT JSONB := '[]'::jsonb; -- Cambiado '{}' a '[]' y asignado el tipo jsonb

BEGIN

  SELECT
    CASE
      WHEN encargado = true THEN 1
      ELSE 2
    END  INTO
    usuario
  FROM usuarios
  WHERE userid = (data->>'idusuario')::INT;
  IF usuario = 1 THEN

    FOR r IN (
        SELECT e.*, s.nombre_sucursal 
        FROM encargadosucursal e 
        JOIN sucursales s ON e.sucursalid = s.sucursalid 
        WHERE encargado = (data ->> 'usuarioid')::int
    )
    LOOP
		RAISE NOTICE 'Este es un mensaje de aviso. %', r.nombre_sucursal;
        FOR x IN (
            SELECT count(*) as total 
            FROM divisas 
            WHERE fecha = CURRENT_DATE AND sucursalid = r.sucursalid
        )
        LOOP
				    RAISE NOTICE 'Este es un mensaje de aviso. %', x.total;

            IF x.total > 0 THEN
                -- Si x.total es mayor que 0, hacer algo aquí si es necesario
            ELSE
                submenus_array := submenus_array || json_build_object('sucursal', r.nombre_sucursal, 'mensaje', 'Agregue una divisa');
            END IF;
        END LOOP;
    END LOOP;

    IF submenus_array IS NULL THEN
        RETURN RESULT;  -- No se han agregado datos a submenus_array
    ELSE
        RETURN json_build_object('info',submenus_array); -- Concatenar los datos al objeto JSON
    END IF;
		end if;
		  IF usuario = 2 THEN
						RETURN '{"message": "XD"}' :: JSON;

			end if;
END;
$$;


ALTER FUNCTION public.validar_divisas(data jsonb) OWNER TO geras;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accesos_rol; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.accesos_rol (
    idacceso integer NOT NULL,
    idrol smallint NOT NULL,
    idcomponete smallint NOT NULL,
    status boolean
);


ALTER TABLE public.accesos_rol OWNER TO geras;

--
-- Name: TABLE accesos_rol; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.accesos_rol IS 'tabla de accesos a menus';


--
-- Name: accesos_rol_idacceso_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.accesos_rol_idacceso_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.accesos_rol_idacceso_seq OWNER TO geras;

--
-- Name: accesos_rol_idacceso_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.accesos_rol_idacceso_seq OWNED BY public.accesos_rol.idacceso;


--
-- Name: cat_dom; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_dom (
    id integer NOT NULL,
    cp text,
    colonia text,
    municipio text,
    estado text,
    idestado smallint
);


ALTER TABLE public.cat_dom OWNER TO geras;

--
-- Name: TABLE cat_dom; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_dom IS 'catalogo de domicilio con base a codigo postal';


--
-- Name: cat_dom_id_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_dom_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_dom_id_seq OWNER TO geras;

--
-- Name: cat_dom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_dom_id_seq OWNED BY public.cat_dom.id;


--
-- Name: cat_estados; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_estados (
    idest integer NOT NULL,
    estado text
);


ALTER TABLE public.cat_estados OWNER TO geras;

--
-- Name: TABLE cat_estados; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_estados IS 'catalogos de estados mexico';


--
-- Name: cat_estados_idest_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_estados_idest_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_estados_idest_seq OWNER TO geras;

--
-- Name: cat_estados_idest_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_estados_idest_seq OWNED BY public.cat_estados.idest;


--
-- Name: cat_estados_paises; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_estados_paises (
    idcatest integer NOT NULL,
    idcatpais smallint,
    nombre text
);


ALTER TABLE public.cat_estados_paises OWNER TO geras;

--
-- Name: TABLE cat_estados_paises; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_estados_paises IS 'catalogo de estados de paises del mundo';


--
-- Name: cat_estados_paises_idcatest_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_estados_paises_idcatest_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cat_estados_paises_idcatest_seq OWNER TO geras;

--
-- Name: cat_estados_paises_idcatest_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_estados_paises_idcatest_seq OWNED BY public.cat_estados_paises.idcatest;


--
-- Name: cat_identificacion; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_identificacion (
    ididentificacion integer NOT NULL,
    descripcion character varying(255)
);


ALTER TABLE public.cat_identificacion OWNER TO geras;

--
-- Name: TABLE cat_identificacion; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_identificacion IS 'catalogo de identificaciones del centro cambiario';


--
-- Name: cat_identificacion_ididentificacion_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_identificacion_ididentificacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_identificacion_ididentificacion_seq OWNER TO geras;

--
-- Name: cat_identificacion_ididentificacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_identificacion_ididentificacion_seq OWNED BY public.cat_identificacion.ididentificacion;


--
-- Name: cat_nacionalidad; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_nacionalidad (
    idnaci integer NOT NULL,
    nacionalidad text,
    clave character varying(255)
);


ALTER TABLE public.cat_nacionalidad OWNER TO geras;

--
-- Name: TABLE cat_nacionalidad; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_nacionalidad IS 'catalogos de nacionalidades ';


--
-- Name: cat_nacionalidad_idnaci_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_nacionalidad_idnaci_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_nacionalidad_idnaci_seq OWNER TO geras;

--
-- Name: cat_nacionalidad_idnaci_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_nacionalidad_idnaci_seq OWNED BY public.cat_nacionalidad.idnaci;


--
-- Name: cat_ocupaciones; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_ocupaciones (
    idacividad integer NOT NULL,
    descripcion character varying(255),
    claveof character varying(255),
    nivel boolean
);


ALTER TABLE public.cat_ocupaciones OWNER TO geras;

--
-- Name: TABLE cat_ocupaciones; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_ocupaciones IS 'catalogo de ocupaciones';


--
-- Name: COLUMN cat_ocupaciones.idacividad; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cat_ocupaciones.idacividad IS ' ';


--
-- Name: cat_ocupaciones_idacividad_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_ocupaciones_idacividad_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_ocupaciones_idacividad_seq OWNER TO geras;

--
-- Name: cat_ocupaciones_idacividad_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_ocupaciones_idacividad_seq OWNED BY public.cat_ocupaciones.idacividad;


--
-- Name: cat_pais; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_pais (
    idpais integer NOT NULL,
    nombre text,
    iso2 character varying(2),
    iso character varying(3),
    lada character varying(5)
);


ALTER TABLE public.cat_pais OWNER TO geras;

--
-- Name: TABLE cat_pais; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_pais IS 'catalogo de paises con claves iso';


--
-- Name: cat_pais_idpais_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_pais_idpais_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_pais_idpais_seq OWNER TO geras;

--
-- Name: cat_pais_idpais_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_pais_idpais_seq OWNED BY public.cat_pais.idpais;


--
-- Name: cat_paises; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_paises (
    idpais integer NOT NULL,
    nombre text
);


ALTER TABLE public.cat_paises OWNER TO geras;

--
-- Name: TABLE cat_paises; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_paises IS 'catalogo de paises si claves';


--
-- Name: cat_paises_idpais_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_paises_idpais_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cat_paises_idpais_seq OWNER TO geras;

--
-- Name: cat_paises_idpais_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_paises_idpais_seq OWNED BY public.cat_paises.idpais;


--
-- Name: cat_reg; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cat_reg (
    id integer NOT NULL,
    idreg character varying(255),
    descripcion character varying(255)
);


ALTER TABLE public.cat_reg OWNER TO geras;

--
-- Name: TABLE cat_reg; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cat_reg IS 'catalogo de registros de regimen fiscal';


--
-- Name: cat_reg_id_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cat_reg_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.cat_reg_id_seq OWNER TO geras;

--
-- Name: cat_reg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cat_reg_id_seq OWNED BY public.cat_reg.id;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cliente (
    idcliente integer NOT NULL,
    tipopersona integer,
    nombre text,
    paterno text,
    materno text,
    idpnaci integer,
    estanaci integer,
    fechanacimiento date,
    correo text,
    curp text,
    rfc text,
    nacionalidad integer,
    telefono text,
    ocupacion integer,
    nif text,
    genero character varying(255),
    ididentificaion integer,
    nident text,
    idcp integer,
    calle character varying(255),
    colonia character varying(255),
    cp text,
    estado text,
    municipio text,
    n_ext text,
    nient text,
    pais text
);


ALTER TABLE public.cliente OWNER TO geras;

--
-- Name: TABLE cliente; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cliente IS 'tabla de clientes fisicos, extranjeros (tipopersona = 1) y morales  (tipopersona = 2) pero solo los representantes que realizan tipos de cambio';


--
-- Name: cliente_empresa; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.cliente_empresa (
    idempresa integer NOT NULL,
    razonsocial text NOT NULL,
    rfc text NOT NULL,
    rfcserie text,
    nacionalidad integer,
    domicilio text NOT NULL,
    telefono text,
    correo text,
    fechaconstitucion date
);


ALTER TABLE public.cliente_empresa OWNER TO geras;

--
-- Name: TABLE cliente_empresa; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.cliente_empresa IS 'catalogo de empresas clientes';


--
-- Name: COLUMN cliente_empresa.razonsocial; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cliente_empresa.razonsocial IS 'nombre de la empresa';


--
-- Name: COLUMN cliente_empresa.rfc; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cliente_empresa.rfc IS 'RFC DE LA EMPRESA';


--
-- Name: COLUMN cliente_empresa.rfcserie; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cliente_empresa.rfcserie IS 'NUMERO DE SERIE DEL RFC';


--
-- Name: COLUMN cliente_empresa.nacionalidad; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cliente_empresa.nacionalidad IS 'nacionalidad de la empresa';


--
-- Name: COLUMN cliente_empresa.domicilio; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cliente_empresa.domicilio IS 'domicilio fiscal';


--
-- Name: COLUMN cliente_empresa.telefono; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.cliente_empresa.telefono IS 'numero de telefono de la empresa';


--
-- Name: cliente_empresa_idempresa_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cliente_empresa_idempresa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_empresa_idempresa_seq OWNER TO geras;

--
-- Name: cliente_empresa_idempresa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cliente_empresa_idempresa_seq OWNED BY public.cliente_empresa.idempresa;


--
-- Name: cliente_idcliente_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.cliente_idcliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_idcliente_seq OWNER TO geras;

--
-- Name: cliente_idcliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.cliente_idcliente_seq OWNED BY public.cliente.idcliente;


--
-- Name: divisas; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.divisas (
    iddivisa integer NOT NULL,
    grupoid smallint,
    compra numeric(10,2),
    venta numeric(10,2),
    fecha timestamp(0) without time zone,
    sucursalid integer
);


ALTER TABLE public.divisas OWNER TO geras;

--
-- Name: TABLE divisas; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.divisas IS 'tabla de divisas por sucursales por dia ';


--
-- Name: COLUMN divisas.iddivisa; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.divisas.iddivisa IS 'id de la divisa';


--
-- Name: COLUMN divisas.grupoid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.divisas.grupoid IS 'id del grupo al que pertenese';


--
-- Name: COLUMN divisas.compra; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.divisas.compra IS 'valor de compra de la moneda';


--
-- Name: COLUMN divisas.venta; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.divisas.venta IS 'valor de la venta de la moneda';


--
-- Name: divisas_iddivisa_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.divisas_iddivisa_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.divisas_iddivisa_seq OWNER TO geras;

--
-- Name: divisas_iddivisa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.divisas_iddivisa_seq OWNED BY public.divisas.iddivisa;


--
-- Name: empresas; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.empresas (
    idempresa integer NOT NULL,
    razonsocial text,
    rfc character varying(13),
    calle text,
    numero character varying(10),
    idcp integer,
    idpais integer,
    telefono text,
    idregimenfiscal integer,
    fechainicioop date,
    emailoc text,
    avisoprivasidad text,
    activo boolean,
    fechacierre date
);


ALTER TABLE public.empresas OWNER TO geras;

--
-- Name: TABLE empresas; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.empresas IS 'tabla de empresas para centro cambiario';


--
-- Name: COLUMN empresas.idempresa; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.idempresa IS 'id de la empresa';


--
-- Name: COLUMN empresas.razonsocial; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.razonsocial IS 'Nombre de la empresa ';


--
-- Name: COLUMN empresas.rfc; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.rfc IS 'Numero de Registro Federa del Contribuyente';


--
-- Name: COLUMN empresas.calle; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.calle IS 'Nombre de la calle del domiciliofisltal';


--
-- Name: COLUMN empresas.numero; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.numero IS 'Numero del domicilio fiscal';


--
-- Name: COLUMN empresas.idcp; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.idcp IS 'Id del Codigo postal seleccionado';


--
-- Name: COLUMN empresas.idpais; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.idpais IS 'Id del pais de la empresa';


--
-- Name: COLUMN empresas.telefono; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.telefono IS 'Telefono de la empresa';


--
-- Name: COLUMN empresas.idregimenfiscal; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.idregimenfiscal IS 'Id del regimen fiscal de la empresa';


--
-- Name: COLUMN empresas.fechainicioop; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.empresas.fechainicioop IS 'Correo electronico del oficial de cumplimiento de la empresa';


--
-- Name: empresas_idempresa_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.empresas_idempresa_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.empresas_idempresa_seq OWNER TO geras;

--
-- Name: empresas_idempresa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.empresas_idempresa_seq OWNED BY public.empresas.idempresa;


--
-- Name: encargadosucursal; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.encargadosucursal (
    idenc integer NOT NULL,
    encargado integer,
    sucursalid integer
);


ALTER TABLE public.encargadosucursal OWNER TO geras;

--
-- Name: TABLE encargadosucursal; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.encargadosucursal IS 'catalogo de usuarios encargados de sucursales ';


--
-- Name: encargadosucursal_idenc_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.encargadosucursal_idenc_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encargadosucursal_idenc_seq OWNER TO geras;

--
-- Name: encargadosucursal_idenc_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.encargadosucursal_idenc_seq OWNED BY public.encargadosucursal.idenc;


--
-- Name: grupodivisa; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.grupodivisa (
    idgrupo integer NOT NULL,
    grupo character varying(255),
    riesgo boolean,
    tipo character varying(255)
);


ALTER TABLE public.grupodivisa OWNER TO geras;

--
-- Name: TABLE grupodivisa; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.grupodivisa IS 'catalogo de grupos de divisas (dolares,euros,pesos)';


--
-- Name: COLUMN grupodivisa.idgrupo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.grupodivisa.idgrupo IS 'id del grupo divisa';


--
-- Name: COLUMN grupodivisa.grupo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.grupodivisa.grupo IS 'nombre de la moneda';


--
-- Name: COLUMN grupodivisa.riesgo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.grupodivisa.riesgo IS 'riesgo de la moneda';


--
-- Name: COLUMN grupodivisa.tipo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.grupodivisa.tipo IS 'denominacion mxn usd etc';


--
-- Name: grupodivisa_idgrupo_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.grupodivisa_idgrupo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.grupodivisa_idgrupo_seq OWNER TO geras;

--
-- Name: grupodivisa_idgrupo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.grupodivisa_idgrupo_seq OWNED BY public.grupodivisa.idgrupo;


--
-- Name: img_suc; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.img_suc (
    idimg integer NOT NULL,
    img text,
    sucursalid integer
);


ALTER TABLE public.img_suc OWNER TO geras;

--
-- Name: img_suc_idimg_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.img_suc_idimg_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.img_suc_idimg_seq OWNER TO geras;

--
-- Name: img_suc_idimg_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.img_suc_idimg_seq OWNED BY public.img_suc.idimg;


--
-- Name: menus; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.menus (
    idmenus integer NOT NULL,
    menu text,
    componente text,
    activo boolean,
    idsubmenu smallint
);


ALTER TABLE public.menus OWNER TO geras;

--
-- Name: TABLE menus; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.menus IS 'Catalogo de menus';


--
-- Name: menus_idmenus_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.menus_idmenus_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.menus_idmenus_seq OWNER TO geras;

--
-- Name: menus_idmenus_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.menus_idmenus_seq OWNED BY public.menus.idmenus;


--
-- Name: menusuperior; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.menusuperior (
    idmenusuperior integer NOT NULL,
    descripcion text
);


ALTER TABLE public.menusuperior OWNER TO geras;

--
-- Name: TABLE menusuperior; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.menusuperior IS 'catalogo de menus superior';


--
-- Name: menusuperior_idmenusuperior_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.menusuperior_idmenusuperior_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menusuperior_idmenusuperior_seq OWNER TO geras;

--
-- Name: menusuperior_idmenusuperior_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.menusuperior_idmenusuperior_seq OWNED BY public.menusuperior.idmenusuperior;


--
-- Name: mov_divisas; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.mov_divisas (
    idmovimiento integer NOT NULL,
    tipo integer NOT NULL,
    grupoid integer,
    mn numeric,
    me numeric,
    sucursalid integer,
    usuarioid integer,
    clienteid integer,
    fecharegistro timestamp without time zone,
    tipocambio numeric
);


ALTER TABLE public.mov_divisas OWNER TO geras;

--
-- Name: TABLE mov_divisas; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.mov_divisas IS 'Registro de compra y venta de divisas';


--
-- Name: COLUMN mov_divisas.tipo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.tipo IS 'tipo se refiere a la compra o venta';


--
-- Name: COLUMN mov_divisas.grupoid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.grupoid IS 'id de la divisa que se cambio';


--
-- Name: COLUMN mov_divisas.mn; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.mn IS 'moneda nacional';


--
-- Name: COLUMN mov_divisas.me; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.me IS 'moneda extranjera';


--
-- Name: COLUMN mov_divisas.sucursalid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.sucursalid IS 'id de la sucursal que realizo el movimiento';


--
-- Name: COLUMN mov_divisas.usuarioid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.usuarioid IS 'id del usuario que realizo el movimiento';


--
-- Name: COLUMN mov_divisas.clienteid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.clienteid IS 'id del cliente que realiza el movimiento';


--
-- Name: COLUMN mov_divisas.fecharegistro; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.fecharegistro IS 'fecha y hora que se realizo el registro';


--
-- Name: COLUMN mov_divisas.tipocambio; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_divisas.tipocambio IS 'el tipo de cambio ya sea de compra o venta moneda nacional';


--
-- Name: mov_divisas_idmovimiento_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.mov_divisas_idmovimiento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mov_divisas_idmovimiento_seq OWNER TO geras;

--
-- Name: mov_divisas_idmovimiento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.mov_divisas_idmovimiento_seq OWNED BY public.mov_divisas.idmovimiento;


--
-- Name: mov_saldos; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.mov_saldos (
    idsaldos integer NOT NULL,
    idsucursalid integer,
    idgrupodivisa integer,
    entrada numeric,
    salida numeric,
    idusuario smallint,
    tipo integer,
    fecharegistro timestamp(6) without time zone,
    descripcion text
);


ALTER TABLE public.mov_saldos OWNER TO geras;

--
-- Name: TABLE mov_saldos; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.mov_saldos IS 'Boveda resgistros de saldos iniciales, y movimientos de compra y venta';


--
-- Name: COLUMN mov_saldos.idsucursalid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.idsucursalid IS 'id de la sucursal';


--
-- Name: COLUMN mov_saldos.idgrupodivisa; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.idgrupodivisa IS 'id de la divisa';


--
-- Name: COLUMN mov_saldos.entrada; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.entrada IS 'cantidad que se va ingresar de esa moneda al centro cambiario para tener un inventario';


--
-- Name: COLUMN mov_saldos.salida; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.salida IS 'cantidad de dinero que sale';


--
-- Name: COLUMN mov_saldos.idusuario; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.idusuario IS 'id del usuario que registro';


--
-- Name: COLUMN mov_saldos.tipo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.tipo IS 'tipo 1 es ingreso de divisas por seguridad, 2 cantidad commprada de dolares para cierre del cajero, 3 cantidad de salida de venta de divisas 4 salida de divisas';


--
-- Name: COLUMN mov_saldos.fecharegistro; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.fecharegistro IS 'fecha de registro';


--
-- Name: COLUMN mov_saldos.descripcion; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.mov_saldos.descripcion IS 'razon del tipo entrada o zalida';


--
-- Name: mov_saldos_idsaldos_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.mov_saldos_idsaldos_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mov_saldos_idsaldos_seq OWNER TO geras;

--
-- Name: mov_saldos_idsaldos_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.mov_saldos_idsaldos_seq OWNED BY public.mov_saldos.idsaldos;


--
-- Name: rel_emp_cli; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.rel_emp_cli (
    idrce integer NOT NULL,
    idc integer,
    ide integer,
    puesto text
);


ALTER TABLE public.rel_emp_cli OWNER TO geras;

--
-- Name: TABLE rel_emp_cli; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.rel_emp_cli IS 'Relacion de empresas con la tabla de clientes para los que estan como registros de las personas relacionadas';


--
-- Name: COLUMN rel_emp_cli.idrce; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.rel_emp_cli.idrce IS 'id de la realcion cliente con empresa';


--
-- Name: COLUMN rel_emp_cli.idc; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.rel_emp_cli.idc IS 'id del cliente';


--
-- Name: COLUMN rel_emp_cli.ide; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.rel_emp_cli.ide IS 'id de la empresa relacionada';


--
-- Name: COLUMN rel_emp_cli.puesto; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.rel_emp_cli.puesto IS 'el puesto que tiene la persona que se va registrar';


--
-- Name: rel_emp_cli_idrce_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.rel_emp_cli_idrce_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rel_emp_cli_idrce_seq OWNER TO geras;

--
-- Name: rel_emp_cli_idrce_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.rel_emp_cli_idrce_seq OWNED BY public.rel_emp_cli.idrce;


--
-- Name: rol; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.rol (
    idrol integer NOT NULL,
    descripcion text
);


ALTER TABLE public.rol OWNER TO geras;

--
-- Name: TABLE rol; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.rol IS 'Catalogos de roles de usuarios sistema
';


--
-- Name: rol_idrol_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.rol_idrol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.rol_idrol_seq OWNER TO geras;

--
-- Name: rol_idrol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.rol_idrol_seq OWNED BY public.rol.idrol;


--
-- Name: sucursal; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.sucursal (
    idempresa integer,
    razonsocial text,
    telefono text,
    cp text,
    colonia text,
    municipio text,
    estado text,
    sucursalid integer,
    nombre_sucursal text,
    cpsuc text,
    colsuc text,
    munsuc text,
    edosuc text
);


ALTER TABLE public.sucursal OWNER TO geras;

--
-- Name: sucursales; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.sucursales (
    sucursalid integer NOT NULL,
    nombre_sucursal text,
    calle text,
    numero character varying(10),
    idcp integer,
    fecharegistro date,
    fechacierre date,
    activa boolean,
    empresaid integer
);


ALTER TABLE public.sucursales OWNER TO geras;

--
-- Name: TABLE sucursales; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.sucursales IS 'Catalogos de sucursales ';


--
-- Name: COLUMN sucursales.sucursalid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.sucursalid IS 'id de la sucursal registrada';


--
-- Name: COLUMN sucursales.nombre_sucursal; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.nombre_sucursal IS 'Nombre de la sucursal ';


--
-- Name: COLUMN sucursales.calle; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.calle IS 'calle de la sucursal';


--
-- Name: COLUMN sucursales.numero; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.numero IS 'numero de la calle de la sucursal';


--
-- Name: COLUMN sucursales.idcp; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.idcp IS 'Id del codigo postal con los datos necesarios del domicilio';


--
-- Name: COLUMN sucursales.fecharegistro; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.fecharegistro IS 'fecha de registro de sucursal';


--
-- Name: COLUMN sucursales.fechacierre; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.fechacierre IS 'fecha de cierre de la sucursal';


--
-- Name: COLUMN sucursales.activa; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.activa IS 'si esta activa la sucursal';


--
-- Name: COLUMN sucursales.empresaid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.sucursales.empresaid IS 'id de relacion con la empresa';


--
-- Name: sucursales_sucursalid_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.sucursales_sucursalid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.sucursales_sucursalid_seq OWNER TO geras;

--
-- Name: sucursales_sucursalid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.sucursales_sucursalid_seq OWNED BY public.sucursales.sucursalid;


--
-- Name: tipo_cambio; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.tipo_cambio (
    id integer NOT NULL,
    dato text,
    fecha date
);


ALTER TABLE public.tipo_cambio OWNER TO geras;

--
-- Name: TABLE tipo_cambio; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.tipo_cambio IS 'Catalogo de tipo de cambio deacuerdo por banxico al dia anterior para las validaciones';


--
-- Name: tipo_cambio_id_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.tipo_cambio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_cambio_id_seq OWNER TO geras;

--
-- Name: tipo_cambio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.tipo_cambio_id_seq OWNED BY public.tipo_cambio.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: geras
--

CREATE TABLE public.usuarios (
    userid integer NOT NULL,
    usuario text,
    contrasena text,
    nombre text,
    paterno text,
    materno text,
    calle text,
    numero character varying(10),
    idcp integer,
    correo text,
    telefono character varying(10),
    activo boolean,
    fecharegistro date,
    fechacierre date,
    usuariomodifico text,
    fechamodificacion date,
    perfilid integer,
    sucursalid integer,
    encargado boolean
);


ALTER TABLE public.usuarios OWNER TO geras;

--
-- Name: TABLE usuarios; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON TABLE public.usuarios IS 'Catalogo de usuarios sistemas ';


--
-- Name: COLUMN usuarios.userid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.userid IS 'id del usuario';


--
-- Name: COLUMN usuarios.usuario; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.usuario IS 'Nombre de usuario asignado por el admin';


--
-- Name: COLUMN usuarios.contrasena; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.contrasena IS 'Contraseña del usuario';


--
-- Name: COLUMN usuarios.nombre; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.nombre IS 'nombre de usuario';


--
-- Name: COLUMN usuarios.paterno; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.paterno IS 'Apellido paterno';


--
-- Name: COLUMN usuarios.materno; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.materno IS 'Apellido Materno';


--
-- Name: COLUMN usuarios.calle; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.calle IS 'Calle del domicilio';


--
-- Name: COLUMN usuarios.numero; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.numero IS 'Numero del Domicilio';


--
-- Name: COLUMN usuarios.idcp; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.idcp IS 'id del codigo postal seleccionado';


--
-- Name: COLUMN usuarios.correo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.correo IS 'correo electronico del usuario';


--
-- Name: COLUMN usuarios.telefono; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.telefono IS 'telefono celular del cliente';


--
-- Name: COLUMN usuarios.activo; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.activo IS 'si es true esta actico si es false desactivado el usuario';


--
-- Name: COLUMN usuarios.fecharegistro; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.fecharegistro IS 'fecha en la que se registro el usuario';


--
-- Name: COLUMN usuarios.fechacierre; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.fechacierre IS 'fecha en la que se dio de baja al usuario';


--
-- Name: COLUMN usuarios.usuariomodifico; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.usuariomodifico IS 'Nombre del usuario que modifico el usuario';


--
-- Name: COLUMN usuarios.fechamodificacion; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.fechamodificacion IS 'fecha en la que se modifico el usuario';


--
-- Name: COLUMN usuarios.perfilid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.perfilid IS 'id del perfil que tiene en la empresa para los accesos';


--
-- Name: COLUMN usuarios.sucursalid; Type: COMMENT; Schema: public; Owner: geras
--

COMMENT ON COLUMN public.usuarios.sucursalid IS 'id de la empresa';


--
-- Name: usuarios_userid_seq; Type: SEQUENCE; Schema: public; Owner: geras
--

CREATE SEQUENCE public.usuarios_userid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.usuarios_userid_seq OWNER TO geras;

--
-- Name: usuarios_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geras
--

ALTER SEQUENCE public.usuarios_userid_seq OWNED BY public.usuarios.userid;


--
-- Name: accesos_rol idacceso; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.accesos_rol ALTER COLUMN idacceso SET DEFAULT nextval('public.accesos_rol_idacceso_seq'::regclass);


--
-- Name: cat_dom id; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_dom ALTER COLUMN id SET DEFAULT nextval('public.cat_dom_id_seq'::regclass);


--
-- Name: cat_estados idest; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_estados ALTER COLUMN idest SET DEFAULT nextval('public.cat_estados_idest_seq'::regclass);


--
-- Name: cat_estados_paises idcatest; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_estados_paises ALTER COLUMN idcatest SET DEFAULT nextval('public.cat_estados_paises_idcatest_seq'::regclass);


--
-- Name: cat_identificacion ididentificacion; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_identificacion ALTER COLUMN ididentificacion SET DEFAULT nextval('public.cat_identificacion_ididentificacion_seq'::regclass);


--
-- Name: cat_nacionalidad idnaci; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_nacionalidad ALTER COLUMN idnaci SET DEFAULT nextval('public.cat_nacionalidad_idnaci_seq'::regclass);


--
-- Name: cat_ocupaciones idacividad; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_ocupaciones ALTER COLUMN idacividad SET DEFAULT nextval('public.cat_ocupaciones_idacividad_seq'::regclass);


--
-- Name: cat_pais idpais; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_pais ALTER COLUMN idpais SET DEFAULT nextval('public.cat_pais_idpais_seq'::regclass);


--
-- Name: cat_paises idpais; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_paises ALTER COLUMN idpais SET DEFAULT nextval('public.cat_paises_idpais_seq'::regclass);


--
-- Name: cat_reg id; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_reg ALTER COLUMN id SET DEFAULT nextval('public.cat_reg_id_seq'::regclass);


--
-- Name: cliente idcliente; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cliente ALTER COLUMN idcliente SET DEFAULT nextval('public.cliente_idcliente_seq'::regclass);


--
-- Name: cliente_empresa idempresa; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cliente_empresa ALTER COLUMN idempresa SET DEFAULT nextval('public.cliente_empresa_idempresa_seq'::regclass);


--
-- Name: divisas iddivisa; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.divisas ALTER COLUMN iddivisa SET DEFAULT nextval('public.divisas_iddivisa_seq'::regclass);


--
-- Name: empresas idempresa; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.empresas ALTER COLUMN idempresa SET DEFAULT nextval('public.empresas_idempresa_seq'::regclass);


--
-- Name: encargadosucursal idenc; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.encargadosucursal ALTER COLUMN idenc SET DEFAULT nextval('public.encargadosucursal_idenc_seq'::regclass);


--
-- Name: grupodivisa idgrupo; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.grupodivisa ALTER COLUMN idgrupo SET DEFAULT nextval('public.grupodivisa_idgrupo_seq'::regclass);


--
-- Name: img_suc idimg; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.img_suc ALTER COLUMN idimg SET DEFAULT nextval('public.img_suc_idimg_seq'::regclass);


--
-- Name: menus idmenus; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.menus ALTER COLUMN idmenus SET DEFAULT nextval('public.menus_idmenus_seq'::regclass);


--
-- Name: menusuperior idmenusuperior; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.menusuperior ALTER COLUMN idmenusuperior SET DEFAULT nextval('public.menusuperior_idmenusuperior_seq'::regclass);


--
-- Name: mov_divisas idmovimiento; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.mov_divisas ALTER COLUMN idmovimiento SET DEFAULT nextval('public.mov_divisas_idmovimiento_seq'::regclass);


--
-- Name: mov_saldos idsaldos; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.mov_saldos ALTER COLUMN idsaldos SET DEFAULT nextval('public.mov_saldos_idsaldos_seq'::regclass);


--
-- Name: rel_emp_cli idrce; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.rel_emp_cli ALTER COLUMN idrce SET DEFAULT nextval('public.rel_emp_cli_idrce_seq'::regclass);


--
-- Name: rol idrol; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.rol ALTER COLUMN idrol SET DEFAULT nextval('public.rol_idrol_seq'::regclass);


--
-- Name: sucursales sucursalid; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.sucursales ALTER COLUMN sucursalid SET DEFAULT nextval('public.sucursales_sucursalid_seq'::regclass);


--
-- Name: tipo_cambio id; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.tipo_cambio ALTER COLUMN id SET DEFAULT nextval('public.tipo_cambio_id_seq'::regclass);


--
-- Name: usuarios userid; Type: DEFAULT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN userid SET DEFAULT nextval('public.usuarios_userid_seq'::regclass);


--
-- Data for Name: accesos_rol; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.accesos_rol (idacceso, idrol, idcomponete, status) FROM stdin;
\.
COPY public.accesos_rol (idacceso, idrol, idcomponete, status) FROM '$$PATH$$/3557.dat';

--
-- Data for Name: cat_dom; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_dom (id, cp, colonia, municipio, estado, idestado) FROM stdin;
\.
COPY public.cat_dom (id, cp, colonia, municipio, estado, idestado) FROM '$$PATH$$/3558.dat';

--
-- Data for Name: cat_estados; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_estados (idest, estado) FROM stdin;
\.
COPY public.cat_estados (idest, estado) FROM '$$PATH$$/3559.dat';

--
-- Data for Name: cat_estados_paises; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_estados_paises (idcatest, idcatpais, nombre) FROM stdin;
\.
COPY public.cat_estados_paises (idcatest, idcatpais, nombre) FROM '$$PATH$$/3579.dat';

--
-- Data for Name: cat_identificacion; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_identificacion (ididentificacion, descripcion) FROM stdin;
\.
COPY public.cat_identificacion (ididentificacion, descripcion) FROM '$$PATH$$/3560.dat';

--
-- Data for Name: cat_nacionalidad; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_nacionalidad (idnaci, nacionalidad, clave) FROM stdin;
\.
COPY public.cat_nacionalidad (idnaci, nacionalidad, clave) FROM '$$PATH$$/3561.dat';

--
-- Data for Name: cat_ocupaciones; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_ocupaciones (idacividad, descripcion, claveof, nivel) FROM stdin;
\.
COPY public.cat_ocupaciones (idacividad, descripcion, claveof, nivel) FROM '$$PATH$$/3562.dat';

--
-- Data for Name: cat_pais; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_pais (idpais, nombre, iso2, iso, lada) FROM stdin;
\.
COPY public.cat_pais (idpais, nombre, iso2, iso, lada) FROM '$$PATH$$/3563.dat';

--
-- Data for Name: cat_paises; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_paises (idpais, nombre) FROM stdin;
\.
COPY public.cat_paises (idpais, nombre) FROM '$$PATH$$/3577.dat';

--
-- Data for Name: cat_reg; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cat_reg (id, idreg, descripcion) FROM stdin;
\.
COPY public.cat_reg (id, idreg, descripcion) FROM '$$PATH$$/3564.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cliente (idcliente, tipopersona, nombre, paterno, materno, idpnaci, estanaci, fechanacimiento, correo, curp, rfc, nacionalidad, telefono, ocupacion, nif, genero, ididentificaion, nident, idcp, calle, colonia, cp, estado, municipio, n_ext, nient, pais) FROM stdin;
\.
COPY public.cliente (idcliente, tipopersona, nombre, paterno, materno, idpnaci, estanaci, fechanacimiento, correo, curp, rfc, nacionalidad, telefono, ocupacion, nif, genero, ididentificaion, nident, idcp, calle, colonia, cp, estado, municipio, n_ext, nient, pais) FROM '$$PATH$$/3581.dat';

--
-- Data for Name: cliente_empresa; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.cliente_empresa (idempresa, razonsocial, rfc, rfcserie, nacionalidad, domicilio, telefono, correo, fechaconstitucion) FROM stdin;
\.
COPY public.cliente_empresa (idempresa, razonsocial, rfc, rfcserie, nacionalidad, domicilio, telefono, correo, fechaconstitucion) FROM '$$PATH$$/3591.dat';

--
-- Data for Name: divisas; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.divisas (iddivisa, grupoid, compra, venta, fecha, sucursalid) FROM stdin;
\.
COPY public.divisas (iddivisa, grupoid, compra, venta, fecha, sucursalid) FROM '$$PATH$$/3565.dat';

--
-- Data for Name: empresas; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.empresas (idempresa, razonsocial, rfc, calle, numero, idcp, idpais, telefono, idregimenfiscal, fechainicioop, emailoc, avisoprivasidad, activo, fechacierre) FROM stdin;
\.
COPY public.empresas (idempresa, razonsocial, rfc, calle, numero, idcp, idpais, telefono, idregimenfiscal, fechainicioop, emailoc, avisoprivasidad, activo, fechacierre) FROM '$$PATH$$/3566.dat';

--
-- Data for Name: encargadosucursal; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.encargadosucursal (idenc, encargado, sucursalid) FROM stdin;
\.
COPY public.encargadosucursal (idenc, encargado, sucursalid) FROM '$$PATH$$/3575.dat';

--
-- Data for Name: grupodivisa; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.grupodivisa (idgrupo, grupo, riesgo, tipo) FROM stdin;
\.
COPY public.grupodivisa (idgrupo, grupo, riesgo, tipo) FROM '$$PATH$$/3567.dat';

--
-- Data for Name: img_suc; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.img_suc (idimg, img, sucursalid) FROM stdin;
\.
COPY public.img_suc (idimg, img, sucursalid) FROM '$$PATH$$/3589.dat';

--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.menus (idmenus, menu, componente, activo, idsubmenu) FROM stdin;
\.
COPY public.menus (idmenus, menu, componente, activo, idsubmenu) FROM '$$PATH$$/3568.dat';

--
-- Data for Name: menusuperior; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.menusuperior (idmenusuperior, descripcion) FROM stdin;
\.
COPY public.menusuperior (idmenusuperior, descripcion) FROM '$$PATH$$/3573.dat';

--
-- Data for Name: mov_divisas; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.mov_divisas (idmovimiento, tipo, grupoid, mn, me, sucursalid, usuarioid, clienteid, fecharegistro, tipocambio) FROM stdin;
\.
COPY public.mov_divisas (idmovimiento, tipo, grupoid, mn, me, sucursalid, usuarioid, clienteid, fecharegistro, tipocambio) FROM '$$PATH$$/3585.dat';

--
-- Data for Name: mov_saldos; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.mov_saldos (idsaldos, idsucursalid, idgrupodivisa, entrada, salida, idusuario, tipo, fecharegistro, descripcion) FROM stdin;
\.
COPY public.mov_saldos (idsaldos, idsucursalid, idgrupodivisa, entrada, salida, idusuario, tipo, fecharegistro, descripcion) FROM '$$PATH$$/3587.dat';

--
-- Data for Name: rel_emp_cli; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.rel_emp_cli (idrce, idc, ide, puesto) FROM stdin;
\.
COPY public.rel_emp_cli (idrce, idc, ide, puesto) FROM '$$PATH$$/3593.dat';

--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.rol (idrol, descripcion) FROM stdin;
\.
COPY public.rol (idrol, descripcion) FROM '$$PATH$$/3569.dat';

--
-- Data for Name: sucursal; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.sucursal (idempresa, razonsocial, telefono, cp, colonia, municipio, estado, sucursalid, nombre_sucursal, cpsuc, colsuc, munsuc, edosuc) FROM stdin;
\.
COPY public.sucursal (idempresa, razonsocial, telefono, cp, colonia, municipio, estado, sucursalid, nombre_sucursal, cpsuc, colsuc, munsuc, edosuc) FROM '$$PATH$$/3594.dat';

--
-- Data for Name: sucursales; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.sucursales (sucursalid, nombre_sucursal, calle, numero, idcp, fecharegistro, fechacierre, activa, empresaid) FROM stdin;
\.
COPY public.sucursales (sucursalid, nombre_sucursal, calle, numero, idcp, fecharegistro, fechacierre, activa, empresaid) FROM '$$PATH$$/3570.dat';

--
-- Data for Name: tipo_cambio; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.tipo_cambio (id, dato, fecha) FROM stdin;
\.
COPY public.tipo_cambio (id, dato, fecha) FROM '$$PATH$$/3583.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: geras
--

COPY public.usuarios (userid, usuario, contrasena, nombre, paterno, materno, calle, numero, idcp, correo, telefono, activo, fecharegistro, fechacierre, usuariomodifico, fechamodificacion, perfilid, sucursalid, encargado) FROM stdin;
\.
COPY public.usuarios (userid, usuario, contrasena, nombre, paterno, materno, calle, numero, idcp, correo, telefono, activo, fecharegistro, fechacierre, usuariomodifico, fechamodificacion, perfilid, sucursalid, encargado) FROM '$$PATH$$/3571.dat';

--
-- Name: accesos_rol_idacceso_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.accesos_rol_idacceso_seq', 14, true);


--
-- Name: cat_dom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_dom_id_seq', 152986, true);


--
-- Name: cat_estados_idest_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_estados_idest_seq', 32, true);


--
-- Name: cat_estados_paises_idcatest_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_estados_paises_idcatest_seq', 1, false);


--
-- Name: cat_identificacion_ididentificacion_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_identificacion_ididentificacion_seq', 2, true);


--
-- Name: cat_nacionalidad_idnaci_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_nacionalidad_idnaci_seq', 177, true);


--
-- Name: cat_ocupaciones_idacividad_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_ocupaciones_idacividad_seq', 25, true);


--
-- Name: cat_pais_idpais_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_pais_idpais_seq', 248, true);


--
-- Name: cat_paises_idpais_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_paises_idpais_seq', 1, false);


--
-- Name: cat_reg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cat_reg_id_seq', 23, true);


--
-- Name: cliente_empresa_idempresa_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cliente_empresa_idempresa_seq', 18, true);


--
-- Name: cliente_idcliente_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.cliente_idcliente_seq', 3, true);


--
-- Name: divisas_iddivisa_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.divisas_iddivisa_seq', 29, true);


--
-- Name: empresas_idempresa_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.empresas_idempresa_seq', 6, true);


--
-- Name: encargadosucursal_idenc_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.encargadosucursal_idenc_seq', 13, true);


--
-- Name: grupodivisa_idgrupo_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.grupodivisa_idgrupo_seq', 8, true);


--
-- Name: img_suc_idimg_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.img_suc_idimg_seq', 1, true);


--
-- Name: menus_idmenus_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.menus_idmenus_seq', 13, true);


--
-- Name: menusuperior_idmenusuperior_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.menusuperior_idmenusuperior_seq', 2, true);


--
-- Name: mov_divisas_idmovimiento_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.mov_divisas_idmovimiento_seq', 27, true);


--
-- Name: mov_saldos_idsaldos_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.mov_saldos_idsaldos_seq', 130, true);


--
-- Name: rel_emp_cli_idrce_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.rel_emp_cli_idrce_seq', 2, true);


--
-- Name: rol_idrol_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.rol_idrol_seq', 6, true);


--
-- Name: sucursales_sucursalid_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.sucursales_sucursalid_seq', 10, true);


--
-- Name: tipo_cambio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.tipo_cambio_id_seq', 33, true);


--
-- Name: usuarios_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: geras
--

SELECT pg_catalog.setval('public.usuarios_userid_seq', 40, true);


--
-- Name: cat_dom cat_dom_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_dom
    ADD CONSTRAINT cat_dom_pkey PRIMARY KEY (id);


--
-- Name: cat_estados_paises cat_estados_paises_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_estados_paises
    ADD CONSTRAINT cat_estados_paises_pkey PRIMARY KEY (idcatest);


--
-- Name: cat_estados cat_estados_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_estados
    ADD CONSTRAINT cat_estados_pkey PRIMARY KEY (idest);


--
-- Name: cat_identificacion cat_identificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_identificacion
    ADD CONSTRAINT cat_identificacion_pkey PRIMARY KEY (ididentificacion);


--
-- Name: cat_nacionalidad cat_nacionalidad_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_nacionalidad
    ADD CONSTRAINT cat_nacionalidad_pkey PRIMARY KEY (idnaci);


--
-- Name: cat_ocupaciones cat_ocupaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_ocupaciones
    ADD CONSTRAINT cat_ocupaciones_pkey PRIMARY KEY (idacividad);


--
-- Name: cat_pais cat_pais_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_pais
    ADD CONSTRAINT cat_pais_pkey PRIMARY KEY (idpais);


--
-- Name: cat_paises cat_paises_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_paises
    ADD CONSTRAINT cat_paises_pkey PRIMARY KEY (idpais);


--
-- Name: cat_reg cat_reg_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cat_reg
    ADD CONSTRAINT cat_reg_pkey PRIMARY KEY (id);


--
-- Name: cliente_empresa cliente_empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cliente_empresa
    ADD CONSTRAINT cliente_empresa_pkey PRIMARY KEY (idempresa);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (idcliente);


--
-- Name: divisas divisas_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.divisas
    ADD CONSTRAINT divisas_pkey PRIMARY KEY (iddivisa);


--
-- Name: empresas empresas_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (idempresa);


--
-- Name: grupodivisa grupodivisa_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.grupodivisa
    ADD CONSTRAINT grupodivisa_pkey PRIMARY KEY (idgrupo);


--
-- Name: img_suc img_suc_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.img_suc
    ADD CONSTRAINT img_suc_pkey PRIMARY KEY (idimg);


--
-- Name: menusuperior menusuperior_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.menusuperior
    ADD CONSTRAINT menusuperior_pkey PRIMARY KEY (idmenusuperior);


--
-- Name: mov_divisas mov_divisas_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.mov_divisas
    ADD CONSTRAINT mov_divisas_pkey PRIMARY KEY (idmovimiento);


--
-- Name: mov_saldos mov_saldos_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.mov_saldos
    ADD CONSTRAINT mov_saldos_pkey PRIMARY KEY (idsaldos);


--
-- Name: rol rol_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (idrol);


--
-- Name: sucursales sucursales_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.sucursales
    ADD CONSTRAINT sucursales_pkey PRIMARY KEY (sucursalid);


--
-- Name: tipo_cambio tipo_cambio_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.tipo_cambio
    ADD CONSTRAINT tipo_cambio_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: geras
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (userid);


--
-- PostgreSQL database dump complete
--

